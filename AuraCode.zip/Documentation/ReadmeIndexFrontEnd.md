# FrontEND
![FrontEND](https://github.com/user-attachments/assets/25e842d6-5107-42f3-890d-96b57891d5cc)

# Agent Creation
![Agent Creation](https://github.com/user-attachments/assets/01a2f538-fe22-4d49-94a5-b2ac11d1dada)

# Founding/Biographical Memories in Agent Creation
![Founding/Biographical Memories](https://github.com/user-attachments/assets/c23ea809-8755-44ae-ae29-093200cc3aad)

# MY Agents Tab
![MY Agents Tab](https://github.com/user-attachments/assets/fad5993d-91ef-42c7-abde-16b9787a8642)

# Chat Window + Specialist call
*(No API key set so it is not working in the image)*

![Chat Window 1](https://github.com/user-attachments/assets/b139a296-9812-47a1-9060-a3efbfb9ca6c)

![Chat Window 2](https://github.com/user-attachments/assets/de07bc9d-c488-44f6-813c-3755677a77f5)

# Memory Control in Agent
![Memory Control 1](https://github.com/user-attachments/assets/9ded3ed0-9219-4a1f-9ee7-f7097a72dcfe)

![Memory Control 2](https://github.com/user-attachments/assets/87c321dd-9fc9-4299-8fdc-6faa0f33c3b2)
