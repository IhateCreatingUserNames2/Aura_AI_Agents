package com.example.cognai.di

import com.example.cognai.data.api.AuraApiService
import com.example.cognai.data.local.TokenManager
import com.example.cognai.data.repository.AgentRepository
import com.example.cognai.data.repository.AuthRepository
import com.example.cognai.data.repository.ChatRepository
import com.example.cognai.utils.AppStateManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Provides
    @Singleton
    fun provideAppStateManager(): AppStateManager {
        return AppStateManager()
    }

    @Provides
    @Singleton
    fun provideAuthRepository(
        apiService: AuraApiService,
        tokenManager: TokenManager
    ): AuthRepository {
        return AuthRepository(apiService, tokenManager)
    }

    @Provides
    @Singleton
    fun provideAgentRepository(
        apiService: AuraApiService
    ): AgentRepository {
        return AgentRepository(apiService)
    }

    @Provides
    @Singleton
    fun provideChatRepository(
        apiService: AuraApiService
    ): ChatRepository {
        return ChatRepository(apiService)
    }
}