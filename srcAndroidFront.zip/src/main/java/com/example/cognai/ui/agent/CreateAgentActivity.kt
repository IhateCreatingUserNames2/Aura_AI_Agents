package com.example.cognai.ui.agent

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.example.cognai.R
import com.example.cognai.data.models.Agent
import com.example.cognai.data.models.PrebuiltAgent
import com.example.cognai.databinding.ActivityCreateAgentBinding
import com.example.cognai.ui.main.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class CreateAgentActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateAgentBinding
    private val viewModel: CreateAgentViewModel by viewModels()
    private lateinit var prebuiltAdapter: PrebuiltAgentAdapter
    private var editingAgent: Agent? = null
    private var currentStep = 0 // 0 = selection, 1 = prebuilt, 2 = scratch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateAgentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Check if we're editing an existing agent
        editingAgent = intent.getParcelableExtra("edit_agent")

        setupToolbar()
        setupUI()
        setupRecyclerView()
        observeViewModel()

        if (editingAgent != null) {
            setupEditMode()
        } else {
            showCreationTypeSelection()
            viewModel.loadPrebuiltAgents()
            viewModel.loadAvailableModels()
        }
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)

        if (editingAgent != null) {
            supportActionBar?.title = "Edit Agent Profile"
        } else {
            supportActionBar?.title = "Create Your AI Companion"
        }
    }

    private fun setupUI() {
        // Creation type selection
        binding.prebuiltOption.setOnClickListener {
            selectCreationType(CreationType.PREBUILT)
        }

        binding.scratchOption.setOnClickListener {
            selectCreationType(CreationType.SCRATCH)
        }

        // System type selection
        binding.ncfSystemOption.setOnClickListener {
            selectSystemType("ncf")
        }

        binding.ceafSystemOption.setOnClickListener {
            selectSystemType("ceaf")
        }

        // Navigation buttons
        binding.nextButton.setOnClickListener { handleNextStep() }
        binding.backButton.setOnClickListener { handleBackStep() }
        binding.createButton.setOnClickListener { createAgent() }

        // Form validation
        setupFormValidation()
    }

    private fun setupRecyclerView() {
        prebuiltAdapter = PrebuiltAgentAdapter { agent ->
            viewModel.selectPrebuiltAgent(agent)
            updateCreateButton()
        }

        binding.prebuiltAgentsRecyclerView.apply {
            layoutManager = GridLayoutManager(this@CreateAgentActivity, 2)
            adapter = prebuiltAdapter
        }
    }

    private fun setupFormValidation() {
        listOf(
            binding.agentNameEditText,
            binding.agentPersonaEditText,
            binding.agentDetailedEditText
        ).forEach { editText ->
            editText.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    updateCreateButton()
                }
            })
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                when (state) {
                    is CreateAgentViewModel.CreateAgentUiState.Loading -> {
                        binding.progressBar.visibility = View.VISIBLE
                        binding.createButton.isEnabled = false
                        binding.nextButton.isEnabled = false
                    }
                    is CreateAgentViewModel.CreateAgentUiState.Success -> {
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(this@CreateAgentActivity, state.message, Toast.LENGTH_LONG).show()

                        // Navigate back to main activity
                        val intent = Intent(this@CreateAgentActivity, MainActivity::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                        startActivity(intent)
                        finish()
                    }
                    is CreateAgentViewModel.CreateAgentUiState.Error -> {
                        binding.progressBar.visibility = View.GONE
                        binding.createButton.isEnabled = true
                        binding.nextButton.isEnabled = true
                        Toast.makeText(this@CreateAgentActivity, state.message, Toast.LENGTH_LONG).show()
                    }
                    is CreateAgentViewModel.CreateAgentUiState.Idle -> {
                        binding.progressBar.visibility = View.GONE
                        updateCreateButton()
                    }
                }
            }
        }

        lifecycleScope.launch {
            viewModel.prebuiltAgents.collect { agents ->
                prebuiltAdapter.submitList(agents)
            }
        }

        lifecycleScope.launch {
            viewModel.availableModels.collect { models ->
                setupModelDropdown(models) // FIX: Renamed the function for clarity
            }
        }

        lifecycleScope.launch {
            viewModel.selectedPrebuiltAgent.collect { agent ->
                updatePrebuiltAgentSelection(agent)
            }
        }
    }

    // FIX: Function updated to work with AutoCompleteTextView
    private fun setupModelDropdown(models: Map<String, List<String>>) {
        val modelItems = mutableListOf<String>()
        val modelValues = mutableListOf<String>()

        models.forEach { (category, modelList) ->
            modelList.forEach { model ->
                // The text displayed in the dropdown
                modelItems.add("$category: $model")
                // The actual value we'll use later
                modelValues.add(model)
            }
        }

        // The adapter is set on the AutoCompleteTextView itself
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, modelItems)
        binding.modelAutoCompleteTextView.setAdapter(adapter)

        // Set default selection to GPT-3.5 Turbo if available
        val defaultIndex = modelValues.indexOfFirst { it.contains("gpt-3.5-turbo") }
        if (defaultIndex != -1) {
            // To set a value on an AutoCompleteTextView, you use setText with the display text
            binding.modelAutoCompleteTextView.setText(modelItems[defaultIndex], false)
        }
    }

    private fun selectCreationType(type: CreationType) {
        viewModel.setCreationType(type)

        // Update UI selection
        binding.prebuiltOption.isSelected = (type == CreationType.PREBUILT)
        binding.scratchOption.isSelected = (type == CreationType.SCRATCH)

        when (type) {
            CreationType.PREBUILT -> {
                currentStep = 1
                showPrebuiltSelection()
            }
            CreationType.SCRATCH -> {
                currentStep = 2
                showScratchForm()
            }
        }
    }

    private fun selectSystemType(systemType: String) {
        viewModel.setSystemType(systemType)

        // Update UI selection
        binding.ncfSystemOption.isSelected = (systemType == "ncf")
        binding.ceafSystemOption.isSelected = (systemType == "ceaf")

        updateCreateButton()
    }

    private fun showCreationTypeSelection() {
        currentStep = 0
        binding.creationTypeContainer.visibility = View.VISIBLE
        binding.prebuiltContainer.visibility = View.GONE
        binding.scratchContainer.visibility = View.GONE
        binding.navigationButtons.visibility = View.GONE
        binding.createButton.visibility = View.GONE
    }

    private fun showPrebuiltSelection() {
        binding.creationTypeContainer.visibility = View.GONE
        binding.prebuiltContainer.visibility = View.VISIBLE
        binding.scratchContainer.visibility = View.GONE
        binding.navigationButtons.visibility = View.VISIBLE
        binding.createButton.visibility = View.VISIBLE

        binding.backButton.text = "Back"
        binding.nextButton.visibility = View.GONE
        updateCreateButton()
    }

    private fun showScratchForm() {
        binding.creationTypeContainer.visibility = View.GONE
        binding.prebuiltContainer.visibility = View.GONE
        binding.scratchContainer.visibility = View.VISIBLE
        binding.navigationButtons.visibility = View.VISIBLE
        binding.createButton.visibility = View.VISIBLE

        binding.backButton.text = "Back"
        binding.nextButton.visibility = View.GONE
        updateCreateButton()
    }

    private fun setupEditMode() {
        editingAgent?.let { agent ->
            // Hide creation type selection and show edit form directly
            binding.creationTypeContainer.visibility = View.GONE
            binding.prebuiltContainer.visibility = View.GONE
            binding.scratchContainer.visibility = View.VISIBLE
            binding.navigationButtons.visibility = View.VISIBLE
            binding.createButton.visibility = View.VISIBLE

            // Pre-populate fields
            binding.agentNameEditText.setText(agent.name)
            binding.agentPersonaEditText.setText(agent.persona)
            binding.agentDetailedEditText.setText(agent.detailedPersona ?: "")

            // Set system type
            val systemType = agent.settings?.systemType ?: "ncf"
            selectSystemType(systemType)

            // Hide system selection in edit mode
            binding.systemTypeContainer.visibility = View.GONE
            binding.modelContainer.visibility = View.GONE

            binding.createButton.text = "Update Profile"
            binding.backButton.text = "Cancel"
            binding.nextButton.visibility = View.GONE

            currentStep = 2
        }
    }

    private fun updatePrebuiltAgentSelection(agent: PrebuiltAgent?) {
        if (agent != null) {
            binding.selectedAgentCard.visibility = View.VISIBLE
            binding.selectedAgentName.text = agent.name
            binding.selectedAgentDescription.text = agent.shortDescription
            binding.selectedAgentSystemType.text = agent.systemType.uppercase()
            binding.selectedAgentArchetype.text = agent.archetype.capitalize()
            binding.selectedAgentRating.text = "★".repeat(agent.rating.toInt()) + " ${agent.rating}"
            binding.selectedAgentDownloads.text = "${agent.downloadCount} downloads"

            // Show custom name field
            binding.customNameContainer.visibility = View.VISIBLE
            binding.customNameEditText.hint = "Custom name (default: ${agent.name})"
        } else {
            binding.selectedAgentCard.visibility = View.GONE
            binding.customNameContainer.visibility = View.GONE
        }
    }

    private fun updateCreateButton() {
        val canCreate = when (currentStep) {
            1 -> viewModel.selectedPrebuiltAgent.value != null // Prebuilt selected
            2 -> { // Scratch form validation
                val name = binding.agentNameEditText.text.toString().trim()
                val persona = binding.agentPersonaEditText.text.toString().trim()
                val detailed = binding.agentDetailedEditText.text.toString().trim()
                name.isNotEmpty() && persona.isNotEmpty() && detailed.isNotEmpty()
            }
            else -> false
        }

        binding.createButton.isEnabled = canCreate

        // Update button text
        binding.createButton.text = when {
            editingAgent != null -> "Update Profile"
            currentStep == 1 -> "Clone Agent"
            currentStep == 2 -> "Create Agent"
            else -> "Create"
        }
    }

    private fun handleNextStep() {
        // Not used currently, but can be for multi-step forms
    }

    private fun handleBackStep() {
        when (currentStep) {
            1, 2 -> {
                // Go back to creation type selection
                showCreationTypeSelection()
                viewModel.clearSelections()
            }
        }
    }

    private fun createAgent() {
        if (editingAgent != null) {
            updateExistingAgent()
        } else {
            createNewAgent()
        }
    }

    private fun updateExistingAgent() {
        val name = binding.agentNameEditText.text.toString().trim()
        val persona = binding.agentPersonaEditText.text.toString().trim()
        val detailedPersona = binding.agentDetailedEditText.text.toString().trim()

        editingAgent?.let { agent ->
            viewModel.updateAgentProfile(
                agentId = agent.id,
                name = name,
                persona = persona,
                detailedPersona = detailedPersona
            )
        }
    }

    private fun createNewAgent() {
        when (currentStep) {
            1 -> createFromPrebuilt()
            2 -> createFromScratch()
        }
    }

    private fun createFromPrebuilt() {
        val customName = binding.customNameEditText.text.toString().trim()
        viewModel.clonePrebuiltAgent(customName.ifEmpty { null })
    }

    private fun createFromScratch() {
        val name = binding.agentNameEditText.text.toString().trim()
        val persona = binding.agentPersonaEditText.text.toString().trim()
        val detailedPersona = binding.agentDetailedEditText.text.toString().trim()

        // FIX: Getting the selected value from an AutoCompleteTextView is much simpler.
        // We just get its text content and parse it.
        val displayText = binding.modelAutoCompleteTextView.text.toString()
        val selectedModel = if (displayText.contains(": ")) {
            displayText.substringAfter(": ")
        } else {
            "openai/gpt-3.5-turbo" // Fallback
        }

        viewModel.createNewAgent(
            name = name,
            persona = persona,
            detailedPersona = detailedPersona,
            model = selectedModel
        )
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressedDispatcher.onBackPressed() // Use the recommended way
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        if (currentStep > 0 && editingAgent == null) {
            handleBackStep()
        } else {
            super.onBackPressed()
        }
    }

    enum class CreationType {
        PREBUILT, SCRATCH
    }
}