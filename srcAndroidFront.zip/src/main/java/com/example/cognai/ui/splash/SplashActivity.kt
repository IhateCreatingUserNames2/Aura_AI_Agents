package com.example.cognai.ui.splash

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.lifecycleScope
import com.example.cognai.data.repository.AuthRepository
import com.example.cognai.ui.auth.AuthActivity
import com.example.cognai.ui.main.MainActivity
import com.example.cognai.utils.AppStateManager
import com.example.cognai.utils.Resource
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.filter // <-- Add this import

@SuppressLint("CustomSplashScreen")
@AndroidEntryPoint
class SplashActivity : AppCompatActivity() {

    @Inject
    lateinit var authRepository: AuthRepository

    @Inject
    lateinit var appStateManager: AppStateManager

    private var hasNavigated = false

    override fun onCreate(savedInstanceState: Bundle?) {
        // Install splash screen
        val splashScreen = installSplashScreen()

        super.onCreate(savedInstanceState)

        // Reset app state
        appStateManager.reset()

        // Keep splash screen visible while checking auth status
        splashScreen.setKeepOnScreenCondition { !hasNavigated }

        // Check authentication status
        lifecycleScope.launch {
            try {
                if (hasNavigated) return@launch

                // FIX: Filter out the Loading state so .first() gets the actual result.
                val resource = authRepository.getCurrentUser()
                    .filter { it !is Resource.Loading }
                    .first()

                if (resource is Resource.Success && resource.data != null) {
                    // Server confirmed the user is valid. Go to Main.
                    appStateManager.setAuthenticationInProgress(true)
                    navigateToMain()
                } else {
                    // Any other result (Error, or Success with null data) means login is required.
                    // This is our catch-all for invalid tokens, expired tokens, no network, etc.
                    appStateManager.setAuthenticationFailed(true)
                    authRepository.logout() // Ensure any bad local data is cleared
                    navigateToAuth()
                }
            } catch (e: Exception) {
                // If the flow throws an exception for any reason, default to safe state: login.
                if (!hasNavigated) {
                    appStateManager.setAuthenticationFailed(true)
                    authRepository.logout()
                    navigateToAuth()
                }
            }
        }
    }

    private fun navigateToMain() {
        if (hasNavigated) return
        hasNavigated = true

        val intent = Intent(this@SplashActivity, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun navigateToAuth() {
        if (hasNavigated) return
        hasNavigated = true

        val intent = Intent(this@SplashActivity, AuthActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        hasNavigated = true
    }
}