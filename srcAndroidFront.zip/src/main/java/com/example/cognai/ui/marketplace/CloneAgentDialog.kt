package com.example.cognai.ui.marketplace

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import com.example.cognai.R
import com.example.cognai.data.models.PrebuiltAgent
import com.example.cognai.databinding.DialogCloneAgentBinding

class CloneAgentDialog : DialogFragment() {

    private var _binding: DialogCloneAgentBinding? = null
    private val binding get() = _binding!!

    private lateinit var agent: PrebuiltAgent
    private var onCloneConfirm: ((String) -> Unit)? = null

    companion object {
        private const val ARG_AGENT = "agent"

        fun newInstance(agent: PrebuiltAgent, onCloneConfirm: (String) -> Unit): CloneAgentDialog {
            return CloneAgentDialog().apply {
                arguments = Bundle().apply {
                    putParcelable(ARG_AGENT, agent)
                }
                this.onCloneConfirm = onCloneConfirm
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.Theme_AuraAI_Dialog)

        agent = arguments?.getParcelable(ARG_AGENT) ?: return
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DialogCloneAgentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupUI()
        setupClickListeners()
    }

    private fun setupUI() {
        binding.apply {
            // Agent info
            agentNameText.text = agent.name
            agentAvatarText.text = agent.name.firstOrNull()?.toString()?.uppercase() ?: "A"
            agentDescriptionText.text = agent.shortDescription

            // System badge
            systemBadgeText.text = agent.systemType.uppercase()
            systemBadgeText.setBackgroundResource(
                if (agent.systemType == "ceaf") R.drawable.bg_ceaf_badge
                else R.drawable.bg_ncf_badge
            )

            // Pre-fill custom name field
            customNameEditText.hint = "Default: ${agent.name}_Clone"

            // Clone information
            val memoryCount = agent.sampleMemories?.size ?: 0
            cloneInfoText.text = getString(
                R.string.clone_info_template,
                agent.name,
                agent.systemType.uppercase(),
                memoryCount
            )

            // Warning for CEAF agents
            if (agent.systemType == "ceaf") {
                ceafWarningLayout.visibility = View.VISIBLE
                ceafWarningText.text = "CEAF agents may behave differently after cloning as they continue to learn and adapt. The original personality will be preserved but may evolve through interactions."
            } else {
                ceafWarningLayout.visibility = View.GONE
            }

            // Memory inclusion checkbox (checked by default)
            includeMemoriesCheckbox.isChecked = true
            includeMemoriesCheckbox.setOnCheckedChangeListener { _, isChecked ->
                memoryWarningText.visibility = if (isChecked) View.GONE else View.VISIBLE
            }
        }
    }

    private fun setupClickListeners() {
        binding.apply {
            cloneButton.setOnClickListener {
                val customName = customNameEditText.text.toString().trim()
                val finalName = if (customName.isNotEmpty()) {
                    customName
                } else {
                    "${agent.name}_Clone"
                }

                onCloneConfirm?.invoke(finalName)
                dismiss()
            }

            cancelButton.setOnClickListener {
                dismiss()
            }

            // Auto-fill suggestions
            suggestionChip1.text = "${agent.name}_Copy"
            suggestionChip2.text = "My_${agent.name}"
            suggestionChip3.text = "${agent.archetype}_AI"

            suggestionChip1.setOnClickListener {
                customNameEditText.setText(suggestionChip1.text)
            }

            suggestionChip2.setOnClickListener {
                customNameEditText.setText(suggestionChip2.text)
            }

            suggestionChip3.setOnClickListener {
                customNameEditText.setText(suggestionChip3.text)
            }
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState)
        dialog.window?.setWindowAnimations(R.style.DialogSlideAnimation)
        return dialog
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}