package com.example.cognai.ui.marketplace

import android.animation.ValueAnimator
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.cognai.R
import com.example.cognai.data.models.PrebuiltAgent
import com.example.cognai.databinding.ItemMarketplaceAgentBinding
import com.google.android.material.chip.Chip

class MarketplaceAdapter(
    private val onAgentClick: (PrebuiltAgent) -> Unit,
    private val onCloneClick: (PrebuiltAgent) -> Unit
) : ListAdapter<PrebuiltAgent, MarketplaceAdapter.MarketplaceViewHolder>(AgentDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MarketplaceViewHolder {
        val binding = ItemMarketplaceAgentBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MarketplaceViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MarketplaceViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    override fun onViewAttachedToWindow(holder: MarketplaceViewHolder) {
        super.onViewAttachedToWindow(holder)
        // Add entrance animation
        holder.itemView.alpha = 0f
        holder.itemView.translationY = 50f
        holder.itemView.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(300)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    inner class MarketplaceViewHolder(
        private val binding: ItemMarketplaceAgentBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(agent: PrebuiltAgent) {
            binding.apply {
                // Basic agent info
                agentNameText.text = agent.name
                agentDescriptionText.text = agent.shortDescription
                agentAvatarText.text = agent.name.firstOrNull()?.toString()?.uppercase() ?: "A"

                // System type badge - FIX: Add null safety
                val systemType = agent.systemType ?: "ncf" // Default to "ncf" if null
                systemBadgeText.text = systemType.uppercase()
                systemBadgeText.setBackgroundResource(
                    if (systemType == "ceaf") R.drawable.bg_ceaf_badge
                    else R.drawable.bg_ncf_badge
                )

                // Archetype - FIX: Add null safety
                archetypeText.text = (agent.archetype ?: "Unknown").replaceFirstChar { it.uppercase() }

                // Maturity level with color coding - FIX: Add null safety
                val maturityLevel = agent.maturityLevel ?: "newborn"
                maturityText.text = maturityLevel.replaceFirstChar { it.uppercase() }
                maturityText.setBackgroundResource(getMaturityBadgeResource(maturityLevel))

                // Rating - FIX: Add safety for rating
                val rating = if (agent.rating.isNaN() || agent.rating < 0) 0f else agent.rating
                val stars = "★".repeat(rating.toInt()) + "☆".repeat(5 - rating.toInt())
                ratingText.text = "$stars ${String.format("%.1f", rating)}"

                // Statistics - FIX: Add safety for counts
                val downloadCount = if (agent.downloadCount < 0) 0 else agent.downloadCount
                val interactionCount = if (agent.totalInteractions < 0) 0 else agent.totalInteractions

                downloadsText.text = formatNumber(downloadCount) + " downloads"
                interactionsText.text = formatNumber(interactionCount) + " conversations"

                // Sample memories section
                setupSampleMemories(agent)

                // Click listeners with ripple effect
                root.setOnClickListener {
                    animateClick(root) {
                        onAgentClick(agent)
                    }
                }

                cloneButton.setOnClickListener {
                    animateButtonClick(cloneButton) {
                        onCloneClick(agent)
                    }
                }

                // Preview button
                previewButton.setOnClickListener {
                    animateButtonClick(previewButton) {
                        onAgentClick(agent)
                    }
                }

                // Add hover effect for clone button
                cloneButton.setOnTouchListener { view, event ->
                    when (event.action) {
                        android.view.MotionEvent.ACTION_DOWN -> {
                            view.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100).start()
                        }
                        android.view.MotionEvent.ACTION_UP,
                        android.view.MotionEvent.ACTION_CANCEL -> {
                            view.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                        }
                    }
                    false
                }
            }
        }

        private fun setupSampleMemories(agent: PrebuiltAgent) {
            binding.sampleMemoriesContainer.removeAllViews()

            // FIX: Add null safety for sample memories
            agent.sampleMemories?.take(3)?.forEach { memory ->
                val chip = Chip(binding.root.context).apply {
                    // FIX: Add null safety for memory content
                    val memoryType = memory.type ?: "Memory"
                    val memoryContent = memory.content ?: "No content"
                    val truncatedContent = if (memoryContent.length > 30) {
                        memoryContent.take(30) + "..."
                    } else {
                        memoryContent
                    }

                    text = "$memoryType: \"$truncatedContent\""
                    setChipBackgroundColorResource(R.color.aura_surface_variant)
                    setTextColor(ContextCompat.getColor(context, R.color.aura_text_secondary))
                    textSize = 10f
                    isClickable = false
                    chipCornerRadius = 12f
                }
                binding.sampleMemoriesContainer.addView(chip)
            }

            // Show/hide sample memories section
            val hasMemories = agent.sampleMemories?.isNotEmpty() == true
            binding.sampleMemoriesSection.visibility = if (hasMemories) View.VISIBLE else View.GONE
        }

        private fun getMaturityBadgeResource(maturityLevel: String): Int {
            return when (maturityLevel.lowercase()) {
                "newborn" -> R.drawable.bg_maturity_newborn
                "learning" -> R.drawable.bg_maturity_learning
                "developing" -> R.drawable.bg_maturity_developing
                "mature" -> R.drawable.bg_maturity_mature
                "experienced" -> R.drawable.bg_maturity_experienced
                "master" -> R.drawable.bg_maturity_master
                else -> R.drawable.bg_maturity_newborn
            }
        }

        private fun formatNumber(number: Int): String {
            return when {
                number >= 1_000_000 -> String.format("%.1fM", number / 1_000_000.0)
                number >= 1_000 -> String.format("%.1fK", number / 1_000.0)
                else -> number.toString()
            }
        }

        private fun animateClick(view: View, onComplete: () -> Unit) {
            val scaleAnimator = ValueAnimator.ofFloat(1f, 0.95f, 1f).apply {
                duration = 200
                addUpdateListener { animation ->
                    val scale = animation.animatedValue as Float
                    view.scaleX = scale
                    view.scaleY = scale
                }
            }

            val elevationAnimator = ValueAnimator.ofFloat(4f, 8f, 4f).apply {
                duration = 200
                addUpdateListener { animation ->
                    view.elevation = animation.animatedValue as Float
                }
            }

            scaleAnimator.start()
            elevationAnimator.start()

            view.postDelayed({ onComplete() }, 100)
        }

        private fun animateButtonClick(button: View, onComplete: () -> Unit) {
            button.animate()
                .scaleX(0.9f)
                .scaleY(0.9f)
                .setDuration(100)
                .withEndAction {
                    button.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(100)
                        .withEndAction { onComplete() }
                        .start()
                }
                .start()
        }
    }

    private class AgentDiffCallback : DiffUtil.ItemCallback<PrebuiltAgent>() {
        override fun areItemsTheSame(oldItem: PrebuiltAgent, newItem: PrebuiltAgent): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: PrebuiltAgent, newItem: PrebuiltAgent): Boolean {
            return oldItem == newItem
        }
    }
}