package com.example.cognai.ui.chat

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.cognai.R
import com.example.cognai.data.models.ChatMessage
import com.example.cognai.databinding.ItemMessageBinding
import io.noties.markwon.Markwon
import java.text.SimpleDateFormat
import java.util.*

class ChatAdapter : ListAdapter<ChatMessage, ChatAdapter.MessageViewHolder>(MessageDiffCallback()) {

    private var markwon: Markwon? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val binding = ItemMessageBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )

        // Initialize Markwon for rich text support
        if (markwon == null) {
            markwon = Markwon.create(parent.context)
        }

        return MessageViewHolder(binding, markwon!!)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class MessageViewHolder(
        private val binding: ItemMessageBinding,
        private val markwon: Markwon
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(message: ChatMessage) {
            binding.apply {
                when (message.role) {
                    "user" -> bindUserMessage(message)
                    "assistant" -> bindAssistantMessage(message)
                    "system" -> bindSystemMessage(message)
                }
            }
        }

        private fun ItemMessageBinding.bindUserMessage(message: ChatMessage) {
            // Hide assistant elements
            assistantMessageLayout.visibility = android.view.View.GONE
            systemMessageLayout.visibility = android.view.View.GONE

            // Show user elements
            userMessageLayout.visibility = android.view.View.VISIBLE

            // Set content
            userMessageText.text = message.content
            userAvatarText.text = "U"

            // Set timestamp
            userTimestampText.text = formatTimestamp(message.timestamp)
        }

        private fun ItemMessageBinding.bindAssistantMessage(message: ChatMessage) {
            // Hide user elements
            userMessageLayout.visibility = android.view.View.GONE
            systemMessageLayout.visibility = android.view.View.GONE

            // Show assistant elements
            assistantMessageLayout.visibility = android.view.View.VISIBLE

            // Set content with Markdown support
            markwon.setMarkdown(assistantMessageText, message.content)
            assistantAvatarText.text = "AI"

            // Set timestamp
            assistantTimestampText.text = formatTimestamp(message.timestamp)
        }

        private fun ItemMessageBinding.bindSystemMessage(message: ChatMessage) {
            // Hide other elements
            userMessageLayout.visibility = android.view.View.GONE
            assistantMessageLayout.visibility = android.view.View.GONE

            // Show system elements
            systemMessageLayout.visibility = android.view.View.VISIBLE

            // Set content
            systemMessageText.text = message.content

            // Color coding for different system message types
            when {
                message.content.startsWith("Error:") -> {
                    systemMessageText.setTextColor(
                        binding.root.context.getColor(R.color.aura_error)
                    )
                }
                message.content.contains("credits") -> {
                    systemMessageText.setTextColor(
                        binding.root.context.getColor(R.color.aura_warning)
                    )
                }
                else -> {
                    systemMessageText.setTextColor(
                        binding.root.context.getColor(R.color.aura_text_secondary)
                    )
                }
            }
        }

        private fun formatTimestamp(timestamp: Long): String {
            val now = System.currentTimeMillis()
            val diff = now - timestamp

            return when {
                diff < 60_000 -> "Just now" // Less than 1 minute
                diff < 3600_000 -> "${diff / 60_000}m ago" // Less than 1 hour
                diff < 86400_000 -> { // Less than 1 day
                    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(timestamp))
                }
                else -> { // More than 1 day
                    SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date(timestamp))
                }
            }
        }
    }

    private class MessageDiffCallback : DiffUtil.ItemCallback<ChatMessage>() {
        override fun areItemsTheSame(oldItem: ChatMessage, newItem: ChatMessage): Boolean {
            return oldItem.timestamp == newItem.timestamp && oldItem.role == newItem.role
        }

        override fun areContentsTheSame(oldItem: ChatMessage, newItem: ChatMessage): Boolean {
            return oldItem == newItem
        }
    }
}