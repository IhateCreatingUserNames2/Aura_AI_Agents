package com.example.cognai.ui.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cognai.data.models.Agent
import com.example.cognai.data.models.AuthResponse
import com.example.cognai.data.repository.AgentRepository
import com.example.cognai.data.repository.AuthRepository
import com.example.cognai.utils.AppStateManager
import com.example.cognai.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val agentRepository: AgentRepository,
    private val authRepository: AuthRepository,
    private val appStateManager: AppStateManager
) : ViewModel() {

    private val _agentsState = MutableStateFlow<Resource<List<Agent>>>(Resource.Loading())
    val agentsState: StateFlow<Resource<List<Agent>>> = _agentsState.asStateFlow()

    private val _userState = MutableStateFlow<Resource<AuthResponse>>(Resource.Loading())
    val userState: StateFlow<Resource<AuthResponse>> = _userState.asStateFlow()

    private val _deleteState = MutableStateFlow<Resource<Unit>?>(null)
    val deleteState: StateFlow<Resource<Unit>?> = _deleteState.asStateFlow()

    private val _authenticationError = MutableStateFlow<Boolean>(false)
    val authenticationError: StateFlow<Boolean> = _authenticationError.asStateFlow()

    private var loadAgentsJob: Job? = null
    private var loadUserJob: Job? = null
    private var deleteAgentJob: Job? = null

    fun loadAgents() {
        // Don't load if auth has failed
        if (appStateManager.hasAuthenticationFailed()) return

        // Cancel previous job if still running
        loadAgentsJob?.cancel()

        loadAgentsJob = viewModelScope.launch {
            agentRepository.getAgents().collect { resource ->
                when (resource) {
                    is Resource.Success -> {
                        _agentsState.value = resource
                    }
                    is Resource.Error -> {
                        if (isAuthenticationError(resource.message) && !appStateManager.isAuthenticationInProgress()) {
                            _authenticationError.value = true
                        } else {
                            _agentsState.value = resource
                        }
                    }
                    is Resource.Loading -> {
                        _agentsState.value = resource
                    }
                    // FIX: Add missing branch
                    is Resource.Idle -> { /* Do nothing */ }
                }
            }
        }
    }

    fun loadUserInfo() {
        // Don't load if auth has failed
        if (appStateManager.hasAuthenticationFailed()) return

        // Cancel previous job if still running
        loadUserJob?.cancel()

        loadUserJob = viewModelScope.launch {
            // First try to get from local storage
            val storedUsername = authRepository.getStoredUsername()
            val storedCredits = authRepository.getStoredCredits()

            if (storedUsername != null) {
                _userState.value = Resource.Success(
                    AuthResponse(
                        accessToken = "",
                        username = storedUsername,
                        credits = storedCredits
                    )
                )
            }

            // Then fetch latest from server only if not in auth process
            if (!appStateManager.isAuthenticationInProgress()) {
                authRepository.getCurrentUser().collect { resource ->
                    when (resource) {
                        is Resource.Success -> {
                            _userState.value = resource
                        }
                        is Resource.Error -> {
                            if (isAuthenticationError(resource.message) && !appStateManager.isAuthenticationInProgress()) {
                                _authenticationError.value = true
                            }

                        }
                        is Resource.Loading -> {

                        }
                        // FIX: Add missing branch
                        is Resource.Idle -> { /* Do nothing */ }
                    }
                }
            }
        }
    }

    fun deleteAgent(agentId: String) {
        // Don't delete if auth has failed
        if (appStateManager.hasAuthenticationFailed()) return

        // Cancel previous delete job if still running
        deleteAgentJob?.cancel()

        deleteAgentJob = viewModelScope.launch {
            agentRepository.deleteAgent(agentId).collect { resource ->
                when (resource) {
                    is Resource.Success -> {
                        _deleteState.value = resource
                    }
                    is Resource.Error -> {
                        if (isAuthenticationError(resource.message) && !appStateManager.isAuthenticationInProgress()) {
                            _authenticationError.value = true
                        } else {
                            _deleteState.value = resource
                        }
                    }
                    is Resource.Loading -> {
                    }
                    // FIX: Add missing branch
                    is Resource.Idle -> { /* Do nothing */ }
                }
            }
        }
    }

    private fun isAuthenticationError(message: String?): Boolean {
        return message?.contains("Not authenticated") == true ||
                message?.contains("403") == true ||
                message?.contains("401") == true
    }

    fun logout() {
        // Cancel all ongoing operations
        loadAgentsJob?.cancel()
        loadUserJob?.cancel()
        deleteAgentJob?.cancel()

        authRepository.logout()
        appStateManager.reset()
    }


    fun clearDeleteState() {
        _deleteState.value = null
    }
    fun clearAuthenticationError() {
        _authenticationError.value = false
    }

    override fun onCleared() {
        super.onCleared()
        // Cancel all jobs when ViewModel is cleared
        loadAgentsJob?.cancel()
        loadUserJob?.cancel()
        deleteAgentJob?.cancel()
    }
}