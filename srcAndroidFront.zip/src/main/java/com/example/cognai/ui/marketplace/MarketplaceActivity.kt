package com.example.cognai.ui.marketplace

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.example.cognai.R
import com.example.cognai.data.models.PrebuiltAgent
import com.example.cognai.databinding.ActivityMarketplaceBinding
import com.example.cognai.ui.main.MainActivity
import com.example.cognai.utils.onError
import com.example.cognai.utils.onLoading
import com.example.cognai.utils.onSuccess
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MarketplaceActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMarketplaceBinding
    private val viewModel: MarketplaceViewModel by viewModels()
    private lateinit var marketplaceAdapter: MarketplaceAdapter

    private val systemTypes = listOf("All Systems", "NCF (Standard)", "CEAF (Emergence)")
    private val archetypes = listOf("All", "Philosopher", "Creative", "Therapist", "Scientist", "Teacher", "Companion")
    private val maturityLevels = listOf("All", "Newborn", "Learning", "Developing", "Mature", "Experienced", "Master")
    private val sortOptions = listOf("Rating", "Downloads", "Name", "Newest")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMarketplaceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupFilters()
        setupRecyclerView()
        setupSwipeRefresh()
        observeViewModel()

        // Load initial data
        viewModel.loadPrebuiltAgents()
        viewModel.loadPublicAgents()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.title = "Agent Marketplace"
    }

    private fun setupFilters() {
        // System Type Filter
        val systemTypeAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, systemTypes)
        binding.systemTypeFilter.setAdapter(systemTypeAdapter)
        binding.systemTypeFilter.setText(systemTypes[0], false)
        binding.systemTypeFilter.setOnItemClickListener { _, _, position, _ ->
            val systemType = when (position) {
                1 -> "ncf"
                2 -> "ceaf"
                else -> null
            }
            viewModel.updateFilters(systemType = systemType)
        }

        // Archetype Filter
        val archetypeAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, archetypes)
        binding.archetypeFilter.setAdapter(archetypeAdapter)
        binding.archetypeFilter.setText(archetypes[0], false)
        binding.archetypeFilter.setOnItemClickListener { _, _, position, _ ->
            val archetype = if (position == 0) null else archetypes[position].lowercase()
            viewModel.updateFilters(archetype = archetype)
        }

        // Maturity Filter
        val maturityAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, maturityLevels)
        binding.maturityFilter.setAdapter(maturityAdapter)
        binding.maturityFilter.setText(maturityLevels[0], false)
        binding.maturityFilter.setOnItemClickListener { _, _, position, _ ->
            val maturity = if (position == 0) null else maturityLevels[position].lowercase()
            viewModel.updateFilters(maturityLevel = maturity)
        }

        // Sort Options
        val sortAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, sortOptions)
        binding.sortSpinner.setAdapter(sortAdapter)
        binding.sortSpinner.setText(sortOptions[0], false)
        binding.sortSpinner.setOnItemClickListener { _, _, position, _ ->
            val sortBy = when (position) {
                0 -> "rating"
                1 -> "downloads"
                2 -> "name"
                3 -> "newest"
                else -> "rating"
            }
            viewModel.updateSorting(sortBy)
        }

        // Search functionality
        binding.searchEditText.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                viewModel.updateSearch(s.toString())
            }
        })

        // Clear filters button
        binding.clearFiltersButton.setOnClickListener {
            clearAllFilters()
        }
    }

    private fun setupRecyclerView() {
        marketplaceAdapter = MarketplaceAdapter(
            onAgentClick = { agent -> showAgentDetails(agent) },
            onCloneClick = { agent -> cloneAgent(agent) }
        )

        binding.agentsRecyclerView.apply {
            // FIX: Change to LinearLayoutManager for single column with better spacing
            layoutManager = androidx.recyclerview.widget.LinearLayoutManager(this@MarketplaceActivity)
            adapter = marketplaceAdapter
            itemAnimator = androidx.recyclerview.widget.DefaultItemAnimator().apply {
                addDuration = 300
                removeDuration = 300
                moveDuration = 300
                changeDuration = 300
            }

            // Add spacing between cards
            addItemDecoration(object : androidx.recyclerview.widget.RecyclerView.ItemDecoration() {
                override fun getItemOffsets(
                    outRect: android.graphics.Rect,
                    view: android.view.View,
                    parent: androidx.recyclerview.widget.RecyclerView,
                    state: androidx.recyclerview.widget.RecyclerView.State
                ) {
                    outRect.bottom = 16 // Space between cards
                    outRect.left = 16
                    outRect.right = 16
                    if (parent.getChildAdapterPosition(view) == 0) {
                        outRect.top = 16 // Space at top for first item
                    }
                }
            })
        }
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefreshLayout.setOnRefreshListener {
            viewModel.refreshAgents()
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.agentsState.collect { resource ->
                resource
                    .onLoading {
                        if (marketplaceAdapter.itemCount == 0) {
                            binding.progressBar.visibility = View.VISIBLE
                            binding.emptyStateLayout.visibility = View.GONE
                        }
                        binding.swipeRefreshLayout.isRefreshing = false
                    }
                    .onSuccess { agents ->
                        binding.progressBar.visibility = View.GONE
                        binding.swipeRefreshLayout.isRefreshing = false

                        if (agents.isNullOrEmpty()) {
                            binding.emptyStateLayout.visibility = View.VISIBLE
                            binding.agentsRecyclerView.visibility = View.GONE
                            updateEmptyStateText()
                        } else {
                            binding.emptyStateLayout.visibility = View.GONE
                            binding.agentsRecyclerView.visibility = View.VISIBLE
                            marketplaceAdapter.submitList(agents)
                        }

                        // Update results count
                        binding.resultsCountText.text = "${agents?.size ?: 0} agents found"
                    }
                    .onError { message ->
                        binding.progressBar.visibility = View.GONE
                        binding.swipeRefreshLayout.isRefreshing = false
                        Toast.makeText(this@MarketplaceActivity, message, Toast.LENGTH_SHORT).show()
                    }
            }
        }

        lifecycleScope.launch {
            viewModel.cloneState.collect { resource ->
                resource
                    ?.onLoading {
                        // Show loading in the specific item or global progress
                    }
                    ?.onSuccess { agent ->
                        // FIX: Add null safety check for agent
                        val agentName = agent?.name ?: "Unknown Agent"
                        Toast.makeText(
                            this@MarketplaceActivity,
                            "Successfully cloned '$agentName'! Check your agent list.",
                            Toast.LENGTH_LONG
                        ).show()
                        viewModel.clearCloneState()
                    }
                    ?.onError { message ->
                        Toast.makeText(this@MarketplaceActivity, message, Toast.LENGTH_LONG).show()
                        viewModel.clearCloneState()
                    }
            }
        }

        lifecycleScope.launch {
            viewModel.currentFilters.collect { filters ->
                updateFilterChips(filters)
            }
        }
    }

    private fun showAgentDetails(agent: PrebuiltAgent) {
        // Create and show agent details dialog or bottom sheet
        val dialog = AgentDetailsDialog.newInstance(agent) { agentToClone ->
            cloneAgent(agentToClone)
        }
        dialog.show(supportFragmentManager, "agent_details")
    }

    private fun cloneAgent(agent: PrebuiltAgent) {
        val dialog = CloneAgentDialog.newInstance(agent) { customName ->
            viewModel.cloneAgent(agent.id, customName)
        }
        dialog.show(supportFragmentManager, "clone_agent")
    }

    private fun clearAllFilters() {
        binding.systemTypeFilter.setText(systemTypes[0], false)
        binding.archetypeFilter.setText(archetypes[0], false)
        binding.maturityFilter.setText(maturityLevels[0], false)
        binding.searchEditText.text?.clear()
        viewModel.clearFilters()
    }

    private fun updateEmptyStateText() {
        val hasFilters = viewModel.hasActiveFilters()
        if (hasFilters) {
            binding.emptyStateTitle.text = "No Agents Match Filters"
            binding.emptyStateSubtitle.text = "Try adjusting your search criteria or clear filters"
            binding.clearFiltersButton.visibility = View.VISIBLE
        } else {
            binding.emptyStateTitle.text = "Marketplace Loading"
            binding.emptyStateSubtitle.text = "Loading available agents..."
            binding.clearFiltersButton.visibility = View.GONE
        }
    }

    private fun updateFilterChips(filters: MarketplaceFilters) {
        binding.activeFiltersGroup.removeAllViews()

        val activeFilters = mutableListOf<String>()

        filters.systemType?.let { activeFilters.add("System: ${it.uppercase()}") }
        filters.archetype?.let { activeFilters.add("Type: ${it.capitalize()}") }
        filters.maturityLevel?.let { activeFilters.add("Maturity: ${it.capitalize()}") }
        if (filters.searchQuery.isNotEmpty()) { activeFilters.add("Search: \"${filters.searchQuery}\"") }

        activeFilters.forEach { filterText ->
            val chip = com.google.android.material.chip.Chip(this).apply {
                text = filterText
                isCloseIconVisible = true
                setOnCloseIconClickListener {
                    // Handle individual filter removal
                    when {
                        filterText.startsWith("System:") -> {
                            binding.systemTypeFilter.setText(systemTypes[0], false)
                            viewModel.updateFilters(systemType = null)
                        }
                        filterText.startsWith("Type:") -> {
                            binding.archetypeFilter.setText(archetypes[0], false)
                            viewModel.updateFilters(archetype = null)
                        }
                        filterText.startsWith("Maturity:") -> {
                            binding.maturityFilter.setText(maturityLevels[0], false)
                            viewModel.updateFilters(maturityLevel = null)
                        }
                        filterText.startsWith("Search:") -> {
                            binding.searchEditText.text?.clear()
                            viewModel.updateSearch("")
                        }
                    }
                }
            }
            binding.activeFiltersGroup.addView(chip)
        }

        binding.activeFiltersContainer.visibility = if (activeFilters.isNotEmpty()) View.VISIBLE else View.GONE
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressedDispatcher.onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        // Navigate back to MainActivity
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        startActivity(intent)
        finish()
    }
}