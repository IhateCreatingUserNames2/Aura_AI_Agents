package com.example.cognai.ui.marketplace

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cognai.data.models.Agent
import com.example.cognai.data.models.PrebuiltAgent
import com.example.cognai.data.repository.AgentRepository
import com.example.cognai.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import javax.inject.Inject

data class MarketplaceFilters(
    val systemType: String? = null,
    val archetype: String? = null,
    val maturityLevel: String? = null,
    val searchQuery: String = "",
    val sortBy: String = "rating" // rating, downloads, name, newest
)

@HiltViewModel
class MarketplaceViewModel @Inject constructor(
    private val agentRepository: AgentRepository
) : ViewModel() {

    private val _agentsState = MutableStateFlow<Resource<List<PrebuiltAgent>>>(Resource.Loading())
    val agentsState: StateFlow<Resource<List<PrebuiltAgent>>> = _agentsState.asStateFlow()

    private val _cloneState = MutableStateFlow<Resource<Agent>?>(null)
    val cloneState: StateFlow<Resource<Agent>?> = _cloneState.asStateFlow()

    private val _currentFilters = MutableStateFlow(MarketplaceFilters())
    val currentFilters: StateFlow<MarketplaceFilters> = _currentFilters.asStateFlow()

    private val _allPrebuiltAgents = MutableStateFlow<List<PrebuiltAgent>>(emptyList())
    private val _allPublicAgents = MutableStateFlow<List<PrebuiltAgent>>(emptyList())

    private var loadJob: Job? = null
    private var cloneJob: Job? = null

    init {
        // Combine filters with agent data to automatically filter results
        viewModelScope.launch {
            combine(
                _allPrebuiltAgents,
                _allPublicAgents,
                _currentFilters
            ) { prebuilt, public, filters ->
                val combined = (prebuilt + public).distinctBy { it.id }
                applyFiltersAndSort(combined, filters)
            }.collect { filteredAgents ->
                _agentsState.value = Resource.Success(filteredAgents)
            }
        }
    }

    fun loadPrebuiltAgents() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            agentRepository.getPrebuiltAgents().collect { resource ->
                when (resource) {
                    is Resource.Success -> {
                        _allPrebuiltAgents.value = resource.data ?: emptyList()
                    }
                    is Resource.Error -> {
                        if (_allPrebuiltAgents.value.isEmpty() && _allPublicAgents.value.isEmpty()) {
                            _agentsState.value = Resource.Error(resource.message ?: "Failed to load prebuilt agents")
                        }
                    }
                    is Resource.Loading -> {
                        if (_allPrebuiltAgents.value.isEmpty() && _allPublicAgents.value.isEmpty()) {
                            _agentsState.value = Resource.Loading()
                        }
                    }
                    is Resource.Idle -> { /* Do nothing */ }
                }
            }
        }
    }

    fun loadPublicAgents() {
        viewModelScope.launch {
            agentRepository.getPublicAgents().collect { resource ->
                when (resource) {
                    is Resource.Success -> {
                        _allPublicAgents.value = resource.data ?: emptyList()
                    }
                    is Resource.Error -> {
                        // Don't override loading state if prebuilt agents are still loading
                        if (_allPrebuiltAgents.value.isEmpty() && _allPublicAgents.value.isEmpty()) {
                            _agentsState.value = Resource.Error(resource.message ?: "Failed to load public agents")
                        }
                    }
                    is Resource.Loading -> {
                        // Loading state handled by prebuilt agents
                    }
                    is Resource.Idle -> { /* Do nothing */ }
                }
            }
        }
    }

    fun refreshAgents() {
        _allPrebuiltAgents.value = emptyList()
        _allPublicAgents.value = emptyList()
        loadPrebuiltAgents()
        loadPublicAgents()
    }

    fun updateFilters(
        systemType: String? = _currentFilters.value.systemType,
        archetype: String? = _currentFilters.value.archetype,
        maturityLevel: String? = _currentFilters.value.maturityLevel,
        searchQuery: String = _currentFilters.value.searchQuery
    ) {
        _currentFilters.value = _currentFilters.value.copy(
            systemType = systemType,
            archetype = archetype,
            maturityLevel = maturityLevel,
            searchQuery = searchQuery
        )
    }

    fun updateSearch(query: String) {
        _currentFilters.value = _currentFilters.value.copy(searchQuery = query)
    }

    fun updateSorting(sortBy: String) {
        _currentFilters.value = _currentFilters.value.copy(sortBy = sortBy)
    }

    fun clearFilters() {
        _currentFilters.value = MarketplaceFilters(sortBy = _currentFilters.value.sortBy)
    }

    fun hasActiveFilters(): Boolean {
        val filters = _currentFilters.value
        return filters.systemType != null ||
                filters.archetype != null ||
                filters.maturityLevel != null ||
                filters.searchQuery.isNotEmpty()
    }

    fun cloneAgent(sourceAgentId: String, customName: String) {
        cloneJob?.cancel()
        cloneJob = viewModelScope.launch {
            _cloneState.value = Resource.Loading()

            agentRepository.cloneAgent(
                sourceAgentId = sourceAgentId,
                customName = customName.ifBlank {
                    // Find the original agent name as fallback
                    val originalAgent = (_allPrebuiltAgents.value + _allPublicAgents.value)
                        .find { it.id == sourceAgentId }
                    originalAgent?.name ?: "Cloned Agent"
                },
                cloneMemories = true
            ).collect { resource ->
                _cloneState.value = resource
            }
        }
    }

    fun clearCloneState() {
        _cloneState.value = null
    }

    private fun applyFiltersAndSort(agents: List<PrebuiltAgent>, filters: MarketplaceFilters): List<PrebuiltAgent> {
        var filteredAgents = agents

        // Apply system type filter
        filters.systemType?.let { systemType ->
            filteredAgents = filteredAgents.filter { it.systemType == systemType }
        }

        // Apply archetype filter
        filters.archetype?.let { archetype ->
            filteredAgents = filteredAgents.filter {
                it.archetype.equals(archetype, ignoreCase = true)
            }
        }

        // Apply maturity level filter
        filters.maturityLevel?.let { maturity ->
            filteredAgents = filteredAgents.filter {
                it.maturityLevel.equals(maturity, ignoreCase = true)
            }
        }

        // Apply search query filter
        if (filters.searchQuery.isNotEmpty()) {
            val query = filters.searchQuery.lowercase()
            filteredAgents = filteredAgents.filter { agent ->
                agent.name.lowercase().contains(query) ||
                        agent.shortDescription.lowercase().contains(query) ||
                        agent.archetype.lowercase().contains(query)
            }
        }

        // Apply sorting
        filteredAgents = when (filters.sortBy) {
            "rating" -> filteredAgents.sortedByDescending { it.rating }
            "downloads" -> filteredAgents.sortedByDescending { it.downloadCount }
            "name" -> filteredAgents.sortedBy { it.name }
            "newest" -> filteredAgents.sortedByDescending { it.totalInteractions } // Proxy for newest
            else -> filteredAgents.sortedByDescending { it.rating }
        }

        return filteredAgents
    }

    fun getAgentById(agentId: String): PrebuiltAgent? {
        return (_allPrebuiltAgents.value + _allPublicAgents.value).find { it.id == agentId }
    }

    fun getFilterSummary(): String {
        val filters = _currentFilters.value
        val activeFilters = mutableListOf<String>()

        filters.systemType?.let { activeFilters.add(it.uppercase()) }
        filters.archetype?.let { activeFilters.add(it.capitalize()) }
        filters.maturityLevel?.let { activeFilters.add(it.capitalize()) }
        if (filters.searchQuery.isNotEmpty()) {
            activeFilters.add("\"${filters.searchQuery}\"")
        }

        return when (activeFilters.size) {
            0 -> "All agents"
            1 -> activeFilters[0]
            2 -> "${activeFilters[0]} & ${activeFilters[1]}"
            else -> "${activeFilters.take(2).joinToString(", ")} & ${activeFilters.size - 2} more"
        }
    }

    override fun onCleared() {
        super.onCleared()
        loadJob?.cancel()
        cloneJob?.cancel()
    }
}