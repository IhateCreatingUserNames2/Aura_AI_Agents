package com.example.cognai.ui.agent

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.cognai.R
import com.example.cognai.data.models.PrebuiltAgent
import com.example.cognai.databinding.ItemPrebuiltAgentBinding

class PrebuiltAgentAdapter(
    private val onAgentSelected: (PrebuiltAgent) -> Unit
) : ListAdapter<PrebuiltAgent, PrebuiltAgentAdapter.PrebuiltAgentViewHolder>(PrebuiltAgentDiffCallback()) {

    private var selectedAgentId: String? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PrebuiltAgentViewHolder {
        val binding = ItemPrebuiltAgentBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return PrebuiltAgentViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PrebuiltAgentViewHolder, position: Int) {
        val agent = getItem(position)
        holder.bind(agent, agent.id == selectedAgentId) { selectedAgent ->
            val previousSelectedId = selectedAgentId
            selectedAgentId = selectedAgent.id

            // Refresh the previously selected item and the newly selected item
            currentList.forEachIndexed { index, item ->
                if (item.id == previousSelectedId || item.id == selectedAgentId) {
                    notifyItemChanged(index)
                }
            }

            onAgentSelected(selectedAgent)
        }
    }

    fun clearSelection() {
        val previousSelectedId = selectedAgentId
        selectedAgentId = null

        if (previousSelectedId != null) {
            currentList.forEachIndexed { index, item ->
                if (item.id == previousSelectedId) {
                    notifyItemChanged(index)
                    return@forEachIndexed
                }
            }
        }
    }

    class PrebuiltAgentViewHolder(
        private val binding: ItemPrebuiltAgentBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(
            agent: PrebuiltAgent,
            isSelected: Boolean,
            onSelected: (PrebuiltAgent) -> Unit
        ) {
            binding.apply {
                // Set agent basic info
                agentNameText.text = agent.name
                agentDescriptionText.text = agent.shortDescription
                agentAvatarText.text = agent.name.firstOrNull()?.toString()?.uppercase() ?: "A"

                // Set system type badge
                systemBadgeText.text = agent.systemType.uppercase()
                systemBadgeText.setBackgroundResource(
                    if (agent.systemType == "ceaf") R.drawable.bg_ceaf_badge
                    else R.drawable.bg_ncf_badge
                )

                // Set archetype and maturity
                archetypeText.text = agent.archetype.capitalize()
                maturityText.text = agent.maturityLevel.capitalize()
                maturityText.setBackgroundResource(getMaturityBadgeResource(agent.maturityLevel))

                // Set statistics
                val stars = "★".repeat(agent.rating.toInt()) + "☆".repeat(5 - agent.rating.toInt())
                ratingText.text = "$stars ${String.format("%.1f", agent.rating)}"
                downloadsText.text = "${agent.downloadCount} downloads"
                interactionsText.text = "${formatNumber(agent.totalInteractions)} conversations"

                // Set selection state
                root.isSelected = isSelected
                root.setBackgroundResource(
                    if (isSelected) R.drawable.bg_agent_card_selected
                    else R.drawable.bg_agent_card
                )

                // Handle selection
                root.setOnClickListener {
                    onSelected(agent)
                }

                // Setup sample memories if available
                setupSampleMemories(agent)
            }
        }

        private fun setupSampleMemories(agent: PrebuiltAgent) {
            binding.sampleMemoriesContainer.removeAllViews()

            agent.sampleMemories?.take(3)?.forEach { memory ->
                val memoryView = LayoutInflater.from(binding.root.context)
                    .inflate(R.layout.item_sample_memory, binding.sampleMemoriesContainer, false)

                val typeText = memoryView.findViewById<android.widget.TextView>(R.id.memoryTypeText)
                val contentText = memoryView.findViewById<android.widget.TextView>(R.id.memoryContentText)

                typeText.text = memory.type
                contentText.text = "\"${memory.content}\""

                binding.sampleMemoriesContainer.addView(memoryView)
            }

            // Show memories container only if there are sample memories
            binding.sampleMemoriesSection.visibility = if (agent.sampleMemories?.isNotEmpty() == true) {
                android.view.View.VISIBLE
            } else {
                android.view.View.GONE
            }
        }

        private fun getMaturityBadgeResource(maturityLevel: String): Int {
            return when (maturityLevel.lowercase()) {
                "newborn" -> R.drawable.bg_maturity_newborn
                "learning" -> R.drawable.bg_maturity_learning
                "developing" -> R.drawable.bg_maturity_developing
                "mature" -> R.drawable.bg_maturity_mature
                "experienced" -> R.drawable.bg_maturity_experienced
                "master" -> R.drawable.bg_maturity_master
                else -> R.drawable.bg_maturity_newborn
            }
        }

        private fun formatNumber(number: Int): String {
            return when {
                number >= 1_000_000 -> String.format("%.1fM", number / 1_000_000.0)
                number >= 1_000 -> String.format("%.1fK", number / 1_000.0)
                else -> number.toString()
            }
        }
    }

    private class PrebuiltAgentDiffCallback : DiffUtil.ItemCallback<PrebuiltAgent>() {
        override fun areItemsTheSame(oldItem: PrebuiltAgent, newItem: PrebuiltAgent): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: PrebuiltAgent, newItem: PrebuiltAgent): Boolean {
            return oldItem == newItem
        }
    }
}