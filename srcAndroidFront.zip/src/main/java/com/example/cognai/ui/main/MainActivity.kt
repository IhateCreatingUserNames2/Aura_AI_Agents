package com.example.cognai.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.example.cognai.R
import com.example.cognai.data.models.Agent
import com.example.cognai.data.repository.AuthRepository
import com.example.cognai.databinding.ActivityMainBinding
import com.example.cognai.ui.agent.CreateAgentActivity
import com.example.cognai.ui.auth.AuthActivity
import com.example.cognai.ui.chat.ChatActivity
import com.example.cognai.utils.AppStateManager
import com.example.cognai.utils.onError
import com.example.cognai.utils.onLoading
import com.example.cognai.utils.onSuccess
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject
import com.example.cognai.ui.main.EnhancedAgentsAdapter
import com.example.cognai.utils.SciFiUtils
import com.example.cognai.ui.components.HolographicView
import com.example.cognai.ui.marketplace.MarketplaceActivity

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var agentsAdapter: EnhancedAgentsAdapter



    @Inject
    lateinit var appStateManager: AppStateManager

    @Inject
    lateinit var authRepository: AuthRepository


    private var hasNavigatedToAuth = false
    private var isInitialLoad = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        setupToolbar()
        setupRecyclerView()
        setupFAB()
        observeViewModel()

        if (isInitialLoad) {
            viewModel.loadUserInfo()
            viewModel.loadAgents()
            isInitialLoad = false


        }
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = getString(R.string.your_ai_companions)
    }

    private fun showMemoryModal(agentId: String) {
        if (hasNavigatedToAuth) return

        val options = arrayOf(
            "View Memory Analytics",
            "Export Memories",
            "Import Memories",
            "Clear All Memories"
        )

        AlertDialog.Builder(this)
            .setTitle("Memory Management")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> Toast.makeText(this, "Loading memory analytics...", Toast.LENGTH_SHORT).show()
                    1 -> Toast.makeText(this, "Exporting memories...", Toast.LENGTH_SHORT).show()
                    2 -> Toast.makeText(this, "Import memories feature coming soon!", Toast.LENGTH_SHORT).show()
                    3 -> showClearMemoriesConfirmation(agentId)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showClearMemoriesConfirmation(agentId: String) {
        AlertDialog.Builder(this)
            .setTitle("Clear All Memories")
            .setMessage("Are you sure you want to clear all memories for this agent? This action cannot be undone.")
            .setPositiveButton("Clear") { _, _ ->
                Toast.makeText(this, "Clearing memories for agent $agentId", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun setupRecyclerView() {
        agentsAdapter = EnhancedAgentsAdapter(
            onAgentClick = { agent -> openChat(agent) },
            onEditClick = { agent -> editAgent(agent) },
            onMemoryClick = { agent -> showMemoryModal(agent.id) },
            onDeleteClick = { agent -> showDeleteConfirmation(agent) }
        )

        binding.agentsRecyclerView.apply {
            // MUDANÇA: 1 coluna em vez de 2
            layoutManager = GridLayoutManager(this@MainActivity, 1)
            adapter = agentsAdapter

            // Adicionar animações de item
            itemAnimator = androidx.recyclerview.widget.DefaultItemAnimator().apply {
                addDuration = 300
                removeDuration = 300
                moveDuration = 300
                changeDuration = 300
            }

            // Adicionar espaçamento entre items
            addItemDecoration(object : androidx.recyclerview.widget.RecyclerView.ItemDecoration() {
                override fun getItemOffsets(
                    outRect: android.graphics.Rect,
                    view: android.view.View,
                    parent: androidx.recyclerview.widget.RecyclerView,
                    state: androidx.recyclerview.widget.RecyclerView.State
                ) {
                    outRect.bottom = 16 // Espaço entre os cards
                    outRect.left = 16
                    outRect.right = 16
                    if (parent.getChildAdapterPosition(view) == 0) {
                        outRect.top = 16 // Espaço no topo do primeiro item
                    }
                }
            })
        }
    }

    private fun setupFAB() {
        binding.createAgentFab.setOnClickListener {
            if (!hasNavigatedToAuth) {
                startActivity(Intent(this, CreateAgentActivity::class.java))
            }
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            // Observe authentication errors
            viewModel.authenticationError.collect { hasAuthError ->
                if (hasAuthError && !hasNavigatedToAuth && !appStateManager.isAuthenticationInProgress()) {
                    redirectToAuth()
                }
            }
        }

        lifecycleScope.launch {
            // Observe agents
            viewModel.agentsState.collect { resource ->
                if (hasNavigatedToAuth) return@collect

                resource
                    .onLoading {
                        if (agentsAdapter.itemCount == 0) {
                            binding.progressBar.visibility = View.VISIBLE
                            binding.emptyStateLayout.visibility = View.GONE
                        }
                        binding.swipeRefreshLayout.isRefreshing = false
                    }
                    .onSuccess { agents ->

                        appStateManager.setAuthenticationInProgress(false)
                        // ---------------------------------------------

                        binding.progressBar.visibility = View.GONE
                        binding.swipeRefreshLayout.isRefreshing = false

                        if (agents.isNullOrEmpty()) {
                            binding.emptyStateLayout.visibility = View.VISIBLE
                            binding.agentsRecyclerView.visibility = View.GONE
                        } else {
                            binding.emptyStateLayout.visibility = View.GONE
                            binding.agentsRecyclerView.visibility = View.VISIBLE
                            agentsAdapter.submitList(agents)
                        }
                    }
                    .onError { message ->
                        binding.progressBar.visibility = View.GONE
                        binding.swipeRefreshLayout.isRefreshing = false

                        // Check for auth errors
                        if (message.contains("Not authenticated") || message.contains("403")) {
                            if (!hasNavigatedToAuth) {
                                redirectToAuth()
                            }
                        } else {
                            // Only show toast for non-auth errors
                            Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
                        }
                    }
            }
        }

        lifecycleScope.launch {
            // Observe user info
            viewModel.userState.collect { resource ->
                if (hasNavigatedToAuth) return@collect

                resource.onSuccess { userInfo ->
                    if (userInfo != null) {
                        supportActionBar?.subtitle = "${userInfo.username} • ${userInfo.credits} credits"
                    }
                }.onError { message ->
                    if (message.contains("Not authenticated") || message.contains("403")) {
                        if (!hasNavigatedToAuth) {
                            redirectToAuth()
                        }
                    }
                }
            }
        }

        lifecycleScope.launch {
            // Observe delete action
            viewModel.deleteState.collect { resource ->

                if (resource == null) {
                    return@collect
                }

                if (hasNavigatedToAuth) return@collect

                resource
                    .onSuccess {
                        Toast.makeText(this@MainActivity, "Agent deleted successfully", Toast.LENGTH_SHORT).show()
                        viewModel.loadAgents() // Refresh the list
                        viewModel.clearDeleteState()
                    }
                    .onError { message ->
                        if (message.contains("Not authenticated") || message.contains("403")) {
                            if (!hasNavigatedToAuth) {
                                redirectToAuth()
                            }
                        } else {
                            Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
                        }
                        viewModel.clearDeleteState()
                    }


            }
        }
    }

    private fun redirectToAuth() {
        if (hasNavigatedToAuth) return
        hasNavigatedToAuth = true

        // Clear the error flag
        viewModel.clearAuthenticationError()
        appStateManager.setAuthenticationFailed(true)

        // Navigate to auth activity
        val intent = Intent(this@MainActivity, AuthActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun openChat(agent: Agent) {
        if (hasNavigatedToAuth) return

        val intent = Intent(this, ChatActivity::class.java).apply {
            putExtra("agent", agent)
        }
        startActivity(intent)
    }

    private fun editAgent(agent: Agent) {
        if (hasNavigatedToAuth) return

        val intent = Intent(this, CreateAgentActivity::class.java).apply {
            putExtra("edit_agent", agent)
        }
        startActivity(intent)
    }

    private fun showDeleteConfirmation(agent: Agent) {
        if (hasNavigatedToAuth) return

        AlertDialog.Builder(this)
            .setTitle("Delete Agent")
            .setMessage(getString(R.string.delete_agent_confirmation))
            .setPositiveButton(getString(R.string.yes)) { _, _ ->
                viewModel.deleteAgent(agent.id)
            }
            .setNegativeButton(getString(R.string.no), null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (hasNavigatedToAuth) return true

        return when (item.itemId) {
            R.id.action_marketplace -> {
                // Navegar para o marketplace
                val intent = Intent(this, MarketplaceActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.action_refresh -> {
                viewModel.loadAgents()
                true
            }
            R.id.action_logout -> {
                showLogoutConfirmation()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showLogoutConfirmation() {
        if (hasNavigatedToAuth) return

        AlertDialog.Builder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Logout") { _, _ ->
                viewModel.logout()
                appStateManager.reset()
                val intent = Intent(this, AuthActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onResume() {
        super.onResume()

        if (!isInitialLoad && !hasNavigatedToAuth && !appStateManager.isAuthenticationInProgress()) {
            viewModel.loadAgents()
            viewModel.loadUserInfo()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Cancel any pending operations
        viewModel.clearAuthenticationError()
    }
}