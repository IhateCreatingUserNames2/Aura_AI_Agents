package com.example.cognai.ui.agent

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cognai.data.models.Agent
import com.example.cognai.data.models.PrebuiltAgent
import com.example.cognai.data.repository.AgentRepository
import com.example.cognai.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CreateAgentViewModel @Inject constructor(
    private val agentRepository: AgentRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<CreateAgentUiState>(CreateAgentUiState.Idle)
    val uiState: StateFlow<CreateAgentUiState> = _uiState.asStateFlow()

    private val _prebuiltAgents = MutableStateFlow<List<PrebuiltAgent>>(emptyList())
    val prebuiltAgents: StateFlow<List<PrebuiltAgent>> = _prebuiltAgents.asStateFlow()

    private val _availableModels = MutableStateFlow<Map<String, List<String>>>(emptyMap())
    val availableModels: StateFlow<Map<String, List<String>>> = _availableModels.asStateFlow()

    private val _selectedPrebuiltAgent = MutableStateFlow<PrebuiltAgent?>(null)
    val selectedPrebuiltAgent: StateFlow<PrebuiltAgent?> = _selectedPrebuiltAgent.asStateFlow()

    private val _creationType = MutableStateFlow<CreateAgentActivity.CreationType?>(null)
    val creationType: StateFlow<CreateAgentActivity.CreationType?> = _creationType.asStateFlow()

    private val _selectedSystemType = MutableStateFlow("ncf")
    val selectedSystemType: StateFlow<String> = _selectedSystemType.asStateFlow()

    sealed class CreateAgentUiState {
        object Idle : CreateAgentUiState()
        object Loading : CreateAgentUiState()
        data class Success(val message: String) : CreateAgentUiState()
        data class Error(val message: String) : CreateAgentUiState()
    }

    fun loadPrebuiltAgents() {
        viewModelScope.launch {
            agentRepository.getPrebuiltAgents().collect { resource ->
                when (resource) {
                    is Resource.Success -> {
                        _prebuiltAgents.value = resource.data ?: emptyList()
                    }
                    is Resource.Error -> {
                        _uiState.value = CreateAgentUiState.Error(resource.message ?: "Failed to load prebuilt agents")
                    }
                    is Resource.Loading -> {
                        // Handle loading state if needed
                    }
                    // FIX: Add missing branch
                    is Resource.Idle -> { /* Do nothing */ }
                }
            }
        }
    }

    fun loadAvailableModels() {
        viewModelScope.launch {
            agentRepository.getAvailableModels().collect { resource ->
                when (resource) {
                    is Resource.Success -> {
                        _availableModels.value = resource.data ?: emptyMap()
                    }
                    is Resource.Error -> {
                        // Don't show error for models, just use default
                        _availableModels.value = getDefaultModels()
                    }
                    is Resource.Loading -> {
                        // Handle loading state if needed
                    }
                    // FIX: Add missing branch
                    is Resource.Idle -> { /* Do nothing */ }
                }
            }
        }
    }

    private fun getDefaultModels(): Map<String, List<String>> {
        return mapOf(
            "OpenAI" to listOf(
                "openai/gpt-4",
                "openai/gpt-4-turbo",
                "openai/gpt-3.5-turbo"
            ),
            "Anthropic" to listOf(
                "anthropic/claude-3-opus",
                "anthropic/claude-3-sonnet",
                "anthropic/claude-3-haiku"
            ),
            "Google" to listOf(
                "google/gemini-pro",
                "google/gemini-pro-vision"
            ),
            "Meta" to listOf(
                "meta-llama/llama-2-70b-chat",
                "meta-llama/llama-2-13b-chat"
            )
        )
    }

    fun setCreationType(type: CreateAgentActivity.CreationType) {
        _creationType.value = type
        _uiState.value = CreateAgentUiState.Idle
    }

    fun setSystemType(systemType: String) {
        _selectedSystemType.value = systemType
    }

    fun selectPrebuiltAgent(agent: PrebuiltAgent) {
        _selectedPrebuiltAgent.value = agent
    }

    fun clearSelections() {
        _selectedPrebuiltAgent.value = null
        _creationType.value = null
        _selectedSystemType.value = "ncf"
        _uiState.value = CreateAgentUiState.Idle
    }

    fun clonePrebuiltAgent(customName: String?) {
        val agent = _selectedPrebuiltAgent.value ?: return

        viewModelScope.launch {
            _uiState.value = CreateAgentUiState.Loading

            agentRepository.cloneAgent(
                sourceAgentId = agent.id,
                customName = customName ?: agent.name,
                cloneMemories = true
            ).collect { resource ->
                when (resource) {
                    is Resource.Success -> {
                        _uiState.value = CreateAgentUiState.Success(
                            "Successfully cloned '${agent.name}'! Your new AI companion is ready to chat."
                        )
                    }
                    is Resource.Error -> {
                        _uiState.value = CreateAgentUiState.Error(
                            resource.message ?: "Failed to clone agent"
                        )
                    }
                    is Resource.Loading -> {
                        _uiState.value = CreateAgentUiState.Loading
                    }
                    // FIX: Add missing branch
                    is Resource.Idle -> { /* Do nothing */ }
                }
            }
        }
    }

    fun createNewAgent(
        name: String,
        persona: String,
        detailedPersona: String,
        model: String
    ) {
        viewModelScope.launch {
            _uiState.value = CreateAgentUiState.Loading

            agentRepository.createAgent(
                name = name,
                persona = persona,
                detailedPersona = detailedPersona,
                systemType = _selectedSystemType.value,
                model = model
            ).collect { resource ->
                when (resource) {
                    is Resource.Success -> {
                        val systemTypeName = if (_selectedSystemType.value == "ceaf") "CEAF" else "NCF"
                        _uiState.value = CreateAgentUiState.Success(
                            "$name created successfully with $systemTypeName capabilities! Your new AI companion is ready to chat."
                        )
                    }
                    is Resource.Error -> {
                        _uiState.value = CreateAgentUiState.Error(
                            resource.message ?: "Failed to create agent"
                        )
                    }
                    is Resource.Loading -> {
                        _uiState.value = CreateAgentUiState.Loading
                    }
                    // FIX: Add missing branch
                    is Resource.Idle -> { /* Do nothing */ }
                }
            }
        }
    }

    fun updateAgentProfile(
        agentId: String,
        name: String,
        persona: String,
        detailedPersona: String
    ) {
        viewModelScope.launch {
            _uiState.value = CreateAgentUiState.Loading

            agentRepository.updateAgentProfile(
                agentId = agentId,
                name = name,
                persona = persona,
                detailedPersona = detailedPersona
            ).collect { resource ->
                when (resource) {
                    is Resource.Success -> {
                        _uiState.value = CreateAgentUiState.Success(
                            "Agent profile updated successfully!"
                        )
                    }
                    is Resource.Error -> {
                        _uiState.value = CreateAgentUiState.Error(
                            resource.message ?: "Failed to update agent profile"
                        )
                    }
                    is Resource.Loading -> {
                        _uiState.value = CreateAgentUiState.Loading
                    }
                    // FIX: Add missing branch
                    is Resource.Idle -> { /* Do nothing */ }
                }
            }
        }
    }

    fun filterPrebuiltAgents(
        systemTypeFilter: String? = null,
        archetypeFilter: String? = null,
        maturityFilter: String? = null
    ) {
        val allAgents = _prebuiltAgents.value

        val filteredAgents = allAgents.filter { agent ->
            val systemMatch = systemTypeFilter.isNullOrEmpty() || agent.systemType == systemTypeFilter
            val archetypeMatch = archetypeFilter.isNullOrEmpty() || agent.archetype == archetypeFilter
            val maturityMatch = maturityFilter.isNullOrEmpty() || agent.maturityLevel == maturityFilter

            systemMatch && archetypeMatch && maturityMatch
        }

        _prebuiltAgents.value = filteredAgents
    }

    fun resetFilters() {
        loadPrebuiltAgents()
    }
}