package com.example.cognai.ui.auth

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.cognai.databinding.ActivityAuthBinding
import com.example.cognai.ui.main.MainActivity
import com.example.cognai.utils.AppStateManager
import com.example.cognai.utils.onError
import com.example.cognai.utils.onLoading
import com.example.cognai.utils.onSuccess
import com.example.cognai.utils.onIdle // <-- ADD THIS IMPORT
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class AuthActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAuthBinding
    private val viewModel: AuthViewModel by viewModels()

    @Inject
    lateinit var appStateManager: AppStateManager

    private var currentAuthMode = "login"
    private var hasNavigated = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAuthBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        observeViewModel()
    }

    private fun setupUI() {
        // Set initial mode
        updateUIForMode(true)

        // Tab clicks
        binding.loginTab.setOnClickListener {
            if (currentAuthMode != "login") {
                currentAuthMode = "login"
                updateUIForMode(true)
            }
        }

        binding.registerTab.setOnClickListener {
            if (currentAuthMode != "register") {
                currentAuthMode = "register"
                updateUIForMode(false)
            }
        }

        // Submit button
        binding.submitButton.setOnClickListener {
            handleSubmit()
        }
    }

    private fun updateUIForMode(loginMode: Boolean) {
        currentAuthMode = if (loginMode) "login" else "register"

        // Update tab appearance
        binding.loginTab.isSelected = loginMode
        binding.registerTab.isSelected = !loginMode

        if (loginMode) {
            binding.submitButton.text = "Login"
            binding.emailInputLayout.visibility = View.GONE
            binding.emailEditText.text?.clear()
        } else {
            binding.submitButton.text = "Register"
            binding.emailInputLayout.visibility = View.VISIBLE
        }
    }

    private fun handleSubmit() {
        if (hasNavigated) return

        val username = binding.usernameEditText.text.toString().trim()
        val password = binding.passwordEditText.text.toString().trim()

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            return
        }

        if (currentAuthMode == "login") {
            viewModel.login(username, password)
        } else {
            val email = binding.emailEditText.text.toString().trim()
            if (email.isEmpty()) {
                Toast.makeText(this, "Please enter your email", Toast.LENGTH_SHORT).show()
                return
            }
            viewModel.register(username, password, email)
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.authState.collect { resource ->
                if (hasNavigated) return@collect

                // FIX: Handle all states explicitly to prevent unwanted navigation
                resource
                    .onIdle {
                        // This is the initial state. UI is ready for input.
                        binding.submitButton.isEnabled = true
                        binding.progressBar.visibility = View.GONE
                    }
                    .onLoading {
                        binding.submitButton.isEnabled = false
                        binding.progressBar.visibility = View.VISIBLE
                    }
                    .onSuccess { authResponse ->
                        // The success block is now only called on a real success.
                        binding.submitButton.isEnabled = true
                        binding.progressBar.visibility = View.GONE

                        if (!hasNavigated) {
                            hasNavigated = true

                            appStateManager.reset()
                            appStateManager.setAuthenticationInProgress(true)

                            // Navigate to main activity
                            val intent = Intent(this@AuthActivity, MainActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                            startActivity(intent)
                            finish()
                        }
                    }
                    .onError { message ->
                        binding.submitButton.isEnabled = true
                        binding.progressBar.visibility = View.GONE

                        if (!hasNavigated) {
                            Toast.makeText(this@AuthActivity, message, Toast.LENGTH_LONG).show()
                        }
                    }
            }
        }
    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        // Prevent going back to splash screen by exiting the app
        finishAffinity()
    }
}