package com.example.cognai.ui.main

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.cognai.R
import com.example.cognai.data.models.Agent
import com.example.cognai.databinding.ItemAgentBinding
import com.google.android.material.chip.Chip
import java.text.SimpleDateFormat
import java.util.*
import com.example.cognai.utils.SciFiUtils

class EnhancedAgentsAdapter(
    private val onAgentClick: (Agent) -> Unit,
    private val onEditClick: (Agent) -> Unit,
    private val onMemoryClick: (Agent) -> Unit,
    private val onDeleteClick: (Agent) -> Unit
) : ListAdapter<Agent, EnhancedAgentsAdapter.SciFiAgentViewHolder>(AgentDiffCallback()) {

    private var recyclerView: RecyclerView? = null

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        this.recyclerView = recyclerView
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SciFiAgentViewHolder {
        val binding = ItemAgentBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return SciFiAgentViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SciFiAgentViewHolder, position: Int) {
        holder.bind(getItem(position), position)
    }

    override fun onViewAttachedToWindow(holder: SciFiAgentViewHolder) {
        super.onViewAttachedToWindow(holder)
        holder.startEntranceAnimation()
    }

    inner class SciFiAgentViewHolder(
        private val binding: ItemAgentBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        private var currentAgent: Agent? = null
        private var glowAnimator: ValueAnimator? = null
        private var scanlineAnimator: ValueAnimator? = null

        init {
            setupClickListeners()
            setupHoverEffects()
        }

        fun bind(agent: Agent, position: Int) {
            currentAgent = agent

            // Stop any running animations
            stopAnimations()

            binding.apply {
                // Set agent basic info with typing effect
                animateTextReveal(agentNameText, agent.name)
                agentAvatarText.text = agent.name.firstOrNull()?.toString()?.uppercase() ?: "A"

                // Set persona with fade-in effect
                animateTextReveal(agentPersonaText, agent.persona, 300)

                // Configure system type with glow effect
                setupSystemBadge(agent)

                // Configure status and creation date
                setupStatusAndDate(agent)

                // Setup capability chips with staggered animation
                setupCapabilityChips(agent, position)

                // Setup holographic effects
                startHolographicEffects()
            }
        }

        private fun setupSystemBadge(agent: Agent) {
            val systemType = agent.settings?.systemType ?: "ncf"
            val isCloned = agent.settings?.clonedFrom != null

            binding.systemBadge.apply {
                text = systemType.uppercase()

                // Animate background color change
                val colorResId = if (systemType == "ceaf") R.color.aura_ceaf else R.color.aura_ncf
                val color = ContextCompat.getColor(context, colorResId)

                ValueAnimator.ofArgb(
                    ContextCompat.getColor(context, R.color.aura_surface_variant),
                    color
                ).apply {
                    duration = 500
                    addUpdateListener { animator ->
                        val animatedColor = animator.animatedValue as Int
                        (background as? GradientDrawable)?.setColor(animatedColor)
                    }
                    start()
                }
            }

            // Show/hide cloned badge with slide animation
            binding.clonedBadge.apply {
                if (isCloned) {
                    visibility = View.VISIBLE
                    alpha = 0f
                    translationX = -50f
                    animate()
                        .alpha(1f)
                        .translationX(0f)
                        .setDuration(400)
                        .setInterpolator(OvershootInterpolator())
                        .start()
                } else {
                    visibility = View.GONE
                }
            }
        }

        private fun setupStatusAndDate(agent: Agent) {
            // Format creation date
            try {
                val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
                val outputFormat = SimpleDateFormat("MMM dd", Locale.getDefault())
                val date = inputFormat.parse(agent.createdAt)
                binding.createdText.text = "Created ${outputFormat.format(date ?: Date())}"
            } catch (e: Exception) {
                binding.createdText.text = "Recently created"
            }

            // Animate status indicator
            binding.statusIndicator.apply {
                alpha = 0f
                scaleX = 0f
                scaleY = 0f

                animate()
                    .alpha(1f)
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(600)
                    .setStartDelay(200)
                    .setInterpolator(OvershootInterpolator())
                    .start()

                // Pulsing effect for online status
                startStatusPulse()
            }
        }

        private fun setupCapabilityChips(agent: Agent, position: Int) {
            binding.capabilityContainer.removeAllViews()

            val systemType = agent.settings?.systemType ?: "ncf"
            val capabilities = listOf(
                "Memory System",
                if (systemType == "ceaf") "Emergence" else "Narrative",
                "Contextual"
            ) + if (systemType == "ceaf") listOf("Breakthrough Learning") else emptyList()

            capabilities.forEachIndexed { index, capability ->
                val chip = Chip(binding.root.context).apply {
                    text = capability
                    setChipBackgroundColorResource(R.color.aura_surface_variant)
                    setTextColor(ContextCompat.getColor(context, R.color.aura_text_secondary_soft))
                    textSize = 10f
                    isClickable = false
                    chipCornerRadius = 24f

                    // Initial state for animation
                    alpha = 0f
                    translationY = 20f
                    scaleX = 0.8f
                    scaleY = 0.8f
                }

                binding.capabilityContainer.addView(chip)

                // Staggered entrance animation
                chip.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(400)
                    .setStartDelay((index * 100).toLong())
                    .setInterpolator(OvershootInterpolator())
                    .start()
            }
        }

        private fun setupClickListeners() {
            binding.root.setOnClickListener {
                currentAgent?.let { agent ->
                    startClickAnimation {
                        onAgentClick(agent)
                    }
                }
            }

            binding.editButton.setOnClickListener {
                currentAgent?.let { agent ->
                    startButtonClickAnimation(binding.editButton) {
                        onEditClick(agent)
                    }
                }
            }

            binding.memoryButton.setOnClickListener {
                currentAgent?.let { agent ->
                    startButtonClickAnimation(binding.memoryButton) {
                        onMemoryClick(agent)
                    }
                }
            }

            binding.deleteButton.setOnClickListener {
                currentAgent?.let { agent ->
                    startButtonClickAnimation(binding.deleteButton) {
                        onDeleteClick(agent)
                    }
                }
            }
        }

        private fun setupHoverEffects() {
            binding.root.setOnTouchListener { view, event ->
                when (event.action) {
                    android.view.MotionEvent.ACTION_DOWN -> {
                        startHoverEffect(true)
                    }
                    android.view.MotionEvent.ACTION_UP,
                    android.view.MotionEvent.ACTION_CANCEL -> {
                        startHoverEffect(false)
                    }
                }
                false // Don't consume the event
            }
        }

        private fun animateTextReveal(textView: android.widget.TextView, text: String, delay: Long = 0) {
            textView.alpha = 0f
            textView.translationY = 10f

            textView.postDelayed({
                textView.text = text
                textView.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setDuration(300)
                    .setInterpolator(AccelerateDecelerateInterpolator())
                    .start()
            }, delay)
        }

        private fun startHolographicEffects() {
            // Subtle glow animation on avatar
            glowAnimator = ValueAnimator.ofFloat(0.3f, 1f).apply {
                duration = 2000
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                interpolator = AccelerateDecelerateInterpolator()

                addUpdateListener { animator ->
                    val alpha = animator.animatedValue as Float
                    binding.avatarContainer.alpha = 0.7f + (alpha * 0.3f)
                }
                start()
            }

            // Holographic bar animation
            binding.holoBar.apply {
                alpha = 0.5f
                ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 3000
                    repeatCount = ValueAnimator.INFINITE
                    repeatMode = ValueAnimator.REVERSE
                    addUpdateListener { animator ->
                        alpha = 0.3f + (animator.animatedValue as Float * 0.7f)
                    }
                    start()
                }
            }
        }

        private fun startStatusPulse() {
            binding.statusIndicator.animate()
                .scaleX(1.2f)
                .scaleY(1.2f)
                .setDuration(800)
                .withEndAction {
                    binding.statusIndicator.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(800)
                        .withEndAction {
                            // Repeat pulse
                            if (binding.statusIndicator.isAttachedToWindow) {
                                startStatusPulse()
                            }
                        }
                        .start()
                }
                .start()
        }

        private fun startHoverEffect(hovering: Boolean) {
            val targetElevation = if (hovering) 16f else 8f
            val targetScale = if (hovering) 1.02f else 1f
            val targetAlpha = if (hovering) 1f else 0.9f

            binding.root.animate()
                .scaleX(targetScale)
                .scaleY(targetScale)
                .alpha(targetAlpha)
                .translationZ(targetElevation)
                .setDuration(200)
                .setInterpolator(AccelerateDecelerateInterpolator())
                .start()
        }

        private fun startClickAnimation(onComplete: () -> Unit) {
            val animatorSet = AnimatorSet()

            val scaleDownX = ObjectAnimator.ofFloat(binding.root, "scaleX", 1f, 0.95f)
            val scaleDownY = ObjectAnimator.ofFloat(binding.root, "scaleY", 1f, 0.95f)
            val scaleUpX = ObjectAnimator.ofFloat(binding.root, "scaleX", 0.95f, 1f)
            val scaleUpY = ObjectAnimator.ofFloat(binding.root, "scaleY", 0.95f, 1f)

            val downSet = AnimatorSet().apply {
                playTogether(scaleDownX, scaleDownY)
                duration = 100
            }

            val upSet = AnimatorSet().apply {
                playTogether(scaleUpX, scaleUpY)
                duration = 100
            }

            animatorSet.apply {
                playSequentially(downSet, upSet)
                start()
            }

            // Scanning effect
            binding.scanningOverlay.apply {
                visibility = View.VISIBLE
                alpha = 0f
                animate()
                    .alpha(1f)
                    .setDuration(150)
                    .withEndAction {
                        animate()
                            .alpha(0f)
                            .setDuration(150)
                            .withEndAction {
                                visibility = View.GONE
                                onComplete()
                            }
                            .start()
                    }
                    .start()
            }
        }

        private fun startButtonClickAnimation(button: View, onComplete: () -> Unit) {
            button.animate()
                .scaleX(0.9f)
                .scaleY(0.9f)
                .setDuration(100)
                .withEndAction {
                    button.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(100)
                        .withEndAction { onComplete() }
                        .start()
                }
                .start()
        }

        fun startEntranceAnimation() {
            binding.root.apply {
                alpha = 0f
                translationY = 50f
                animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setDuration(500)
                    .setInterpolator(OvershootInterpolator())
                    .start()
            }
        }

        private fun stopAnimations() {
            glowAnimator?.cancel()
            scanlineAnimator?.cancel()
            binding.root.animate().cancel()
            binding.statusIndicator.animate().cancel()
        }
    }

    private class AgentDiffCallback : DiffUtil.ItemCallback<Agent>() {
        override fun areItemsTheSame(oldItem: Agent, newItem: Agent): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Agent, newItem: Agent): Boolean {
            return oldItem == newItem
        }
    }
}