package com.example.cognai.ui.components

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.example.cognai.R
import kotlin.math.sin

class HolographicView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var holoColor = ContextCompat.getColor(context, R.color.holo_blue)
    private var glowRadius = 8f
    private var shimmerDuration = 2000
    private var scanlineSpeed = 1f

    private val holoPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val scanlinePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var shimmerOffset = 0f
    private var scanlinePosition = 0f

    private var shimmerAnimator: ValueAnimator? = null
    private var scanlineAnimator: ValueAnimator? = null

    init {
        // Load custom attributes
        context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.HolographicView,
            0, 0
        ).apply {
            try {
                holoColor = getColor(R.styleable.HolographicView_holoColor, holoColor)
                glowRadius = getDimension(R.styleable.HolographicView_glowRadius, glowRadius)
                shimmerDuration = getInteger(R.styleable.HolographicView_shimmerDuration, shimmerDuration)
                scanlineSpeed = getFloat(R.styleable.HolographicView_scanlineSpeed, scanlineSpeed)
            } finally {
                recycle()
            }
        }

        setupPaints()
        startAnimations()
    }

    private fun setupPaints() {
        holoPaint.apply {
            color = holoColor
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }

        glowPaint.apply {
            color = holoColor
            style = Paint.Style.STROKE
            strokeWidth = 4f
            maskFilter = BlurMaskFilter(glowRadius, BlurMaskFilter.Blur.OUTER)
        }

        scanlinePaint.apply {
            shader = LinearGradient(
                0f, 0f, width.toFloat(), 0f,
                intArrayOf(Color.TRANSPARENT, holoColor, Color.TRANSPARENT),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
            alpha = 100
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val centerX = width / 2f
        val centerY = height / 2f
        val radius = (width.coerceAtMost(height) / 2f) - glowRadius

        // Draw holographic circle with shimmer effect
        val shimmerAlpha = (sin(shimmerOffset) * 0.3f + 0.7f) * 255
        holoPaint.alpha = shimmerAlpha.toInt()
        glowPaint.alpha = (shimmerAlpha * 0.5f).toInt()

        // Draw glow
        canvas.drawCircle(centerX, centerY, radius, glowPaint)

        // Draw main circle
        canvas.drawCircle(centerX, centerY, radius, holoPaint)

        // Draw scanning line
        val scanlineY = scanlinePosition * height
        canvas.drawLine(0f, scanlineY, width.toFloat(), scanlineY, scanlinePaint)

        // Draw corner accents
        drawCornerAccents(canvas)
    }

    private fun drawCornerAccents(canvas: Canvas) {
        val accentLength = 20f
        val margin = 10f

        // Top-left
        canvas.drawLine(margin, margin, margin + accentLength, margin, holoPaint)
        canvas.drawLine(margin, margin, margin, margin + accentLength, holoPaint)

        // Top-right
        canvas.drawLine(width - margin, margin, width - margin - accentLength, margin, holoPaint)
        canvas.drawLine(width - margin, margin, width - margin, margin + accentLength, holoPaint)

        // Bottom-left
        canvas.drawLine(margin, height - margin, margin + accentLength, height - margin, holoPaint)
        canvas.drawLine(margin, height - margin, margin, height - margin - accentLength, holoPaint)

        // Bottom-right
        canvas.drawLine(width - margin, height - margin, width - margin - accentLength, height - margin, holoPaint)
        canvas.drawLine(width - margin, height - margin, width - margin, height - margin - accentLength, holoPaint)
    }

    private fun startAnimations() {
        // Shimmer animation
        shimmerAnimator = ValueAnimator.ofFloat(0f, 2 * Math.PI.toFloat()).apply {
            duration = shimmerDuration.toLong()
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { animator ->
                shimmerOffset = animator.animatedValue as Float
                invalidate()
            }
            start()
        }

        // Scanline animation
        scanlineAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = (3000 / scanlineSpeed).toLong()
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { animator ->
                scanlinePosition = animator.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        shimmerAnimator?.cancel()
        scanlineAnimator?.cancel()
    }

    fun setHoloColor(color: Int) {
        holoColor = color
        setupPaints()
        invalidate()
    }

    fun setGlowRadius(radius: Float) {
        glowRadius = radius
        setupPaints()
        invalidate()
    }
}



