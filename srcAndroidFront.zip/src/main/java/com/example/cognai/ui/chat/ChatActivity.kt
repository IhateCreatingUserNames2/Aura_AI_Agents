package com.example.cognai.ui.chat

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cognai.R
import com.example.cognai.data.models.Agent
import com.example.cognai.data.models.ChatMessage
import com.example.cognai.databinding.ActivityChatBinding
import com.example.cognai.utils.onError
import com.example.cognai.utils.onLoading
import com.example.cognai.utils.onSuccess
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.util.*

@AndroidEntryPoint
class ChatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChatBinding
    private val viewModel: ChatViewModel by viewModels()
    private lateinit var chatAdapter: ChatAdapter
    private var agent: Agent? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Get agent from intent
        agent = intent.getParcelableExtra("agent")
        if (agent == null) {
            Toast.makeText(this, "Error: No agent specified", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        setupToolbar()
        setupRecyclerView()
        setupInputField()
        viewModel.initializeChat(agent!!.id)
        observeViewModel()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)

        agent?.let { agent ->
            binding.agentNameText.text = agent.name
            binding.agentAvatarText.text = agent.name.firstOrNull()?.toString()?.uppercase() ?: "A"

            val systemType = agent.settings?.systemType ?: "ncf"
            binding.agentStatusText.text = "${systemType.uppercase()}-Enabled • Online"
        }
    }

    private fun setupRecyclerView() {
        chatAdapter = ChatAdapter()

        binding.messagesRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@ChatActivity).apply {
                stackFromEnd = true
            }
            adapter = chatAdapter
        }
    }

    private fun setupInputField() {
        binding.messageEditText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage()
                true
            } else {
                false
            }
        }

        binding.sendButton.setOnClickListener {
            sendMessage()
        }
    }

    private fun sendMessage() {
        val messageText = binding.messageEditText.text.toString().trim()
        if (messageText.isEmpty()) return

        binding.messageEditText.text?.clear()
        viewModel.sendMessage(messageText)
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.messages.collect { messages ->
                chatAdapter.submitList(messages) {
                    if (messages.isNotEmpty()) {
                        binding.messagesRecyclerView.scrollToPosition(messages.size - 1)
                    }
                }
            }
        }

        lifecycleScope.launch {
            viewModel.chatState.collect { resource ->
                resource
                    .onLoading {
                        binding.sendButton.isEnabled = false
                        binding.progressBar.visibility = View.VISIBLE
                        showTypingIndicator(true)
                    }
                    .onSuccess { response ->
                        binding.sendButton.isEnabled = true
                        binding.progressBar.visibility = View.GONE
                        showTypingIndicator(false)
                    }
                    .onError { message ->
                        binding.sendButton.isEnabled = true
                        binding.progressBar.visibility = View.GONE
                        showTypingIndicator(false)
                        Toast.makeText(this@ChatActivity, message, Toast.LENGTH_LONG).show()
                    }
            }
        }

        lifecycleScope.launch {
            viewModel.isTyping.collect { isTyping ->
                showTypingIndicator(isTyping)
            }
        }
    }

    private fun showTypingIndicator(show: Boolean) {
        binding.typingIndicator.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            binding.typingText.text = "${agent?.name} is thinking..."
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.saveChatHistory()
    }
}