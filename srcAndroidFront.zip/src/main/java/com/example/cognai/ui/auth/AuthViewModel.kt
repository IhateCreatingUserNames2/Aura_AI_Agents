package com.example.cognai.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cognai.data.models.AuthResponse
import com.example.cognai.data.repository.AuthRepository
import com.example.cognai.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    // FIX: Change initial state from Resource.Success(null) to Resource.Idle()
    private val _authState = MutableStateFlow<Resource<AuthResponse>>(Resource.Idle())
    val authState: StateFlow<Resource<AuthResponse>> = _authState.asStateFlow()

    fun login(username: String, password: String) {
        viewModelScope.launch {
            authRepository.login(username, password).collect { resource ->
                _authState.value = resource
            }
        }
    }

    fun register(username: String, password: String, email: String) {
        viewModelScope.launch {
            authRepository.register(username, password, email).collect { resource ->
                _authState.value = resource
            }
        }
    }
}