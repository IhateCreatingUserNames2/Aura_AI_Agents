package com.example.cognai.ui.chat

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cognai.data.models.ChatMessage
import com.example.cognai.data.models.ChatResponse
import com.example.cognai.data.repository.AuthRepository
import com.example.cognai.data.repository.ChatRepository
import com.example.cognai.utils.Resource
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val authRepository: AuthRepository,
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _chatState = MutableStateFlow<Resource<ChatResponse>>(Resource.Idle()) // Changed to Idle
    val chatState: StateFlow<Resource<ChatResponse>> = _chatState.asStateFlow()

    private val _isTyping = MutableStateFlow(false)
    val isTyping: StateFlow<Boolean> = _isTyping.asStateFlow()

    private var currentAgentId: String = ""
    private var sessionId: String = ""
    private val gson = Gson()

    fun initializeChat(agentId: String) {
        currentAgentId = agentId
        sessionId = generateSessionId()
        loadChatHistory()

        // Add welcome message if no history exists
        if (_messages.value.isEmpty()) {
            addMessage("assistant", "Hello! How can I help you today?")
        }
    }

    fun sendMessage(messageText: String) {
        // Add user message immediately
        addMessage("user", messageText)

        // Send to API
        viewModelScope.launch {
            _isTyping.value = true

            // Add small delay for better UX
            delay(500)

            chatRepository.sendMessage(currentAgentId, messageText, sessionId)
                .collect { resource ->
                    _chatState.value = resource

                    when (resource) {
                        is Resource.Success -> {
                            _isTyping.value = false
                            resource.data?.let { response ->
                                addMessage("assistant", response.response)

                                // Update user credits if available
                                if (response.response.contains("credits")) {
                                    // Refresh user info to update credit count
                                    refreshUserCredits()
                                }
                            }
                        }
                        is Resource.Error -> {
                            _isTyping.value = false
                            // Add error message as system message
                            addMessage("system", "Error: ${resource.message}")
                        }
                        is Resource.Loading -> {
                            // Keep typing indicator active
                        }
                        // FIX: Add missing branch
                        is Resource.Idle -> { /* Do nothing */ }
                    }
                }
        }
    }

    private fun addMessage(role: String, content: String) {
        val message = ChatMessage(
            role = role,
            content = content,
            timestamp = System.currentTimeMillis(),
            sessionId = sessionId
        )

        val currentMessages = _messages.value.toMutableList()
        currentMessages.add(message)
        _messages.value = currentMessages

        saveChatHistory()
    }

    private fun generateSessionId(): String {
        return "session_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}"
    }

    private fun getChatHistoryKey(): String {
        return "chat_history_${currentAgentId}_${sessionId}"
    }

    private fun loadChatHistory() {
        try {
            val sharedPrefs = context.getSharedPreferences("aura_prefs", Context.MODE_PRIVATE)

            // Try to load existing session for this agent
            val existingSessionKey = "current_session_$currentAgentId"
            val existingSession = sharedPrefs.getString(existingSessionKey, null)

            if (existingSession != null) {
                sessionId = existingSession
                val historyKey = getChatHistoryKey()
                val historyJson = sharedPrefs.getString(historyKey, null)

                if (historyJson != null) {
                    val type = object : TypeToken<List<ChatMessage>>() {}.type
                    val messages: List<ChatMessage> = gson.fromJson(historyJson, type)
                    _messages.value = messages
                    return
                }
            }

            // If no existing session, create new one and save it
            sharedPrefs.edit()
                .putString(existingSessionKey, sessionId)
                .apply()

        } catch (e: Exception) {
            // If loading fails, start with empty history
            _messages.value = emptyList()
        }
    }

    fun saveChatHistory() {
        try {
            val sharedPrefs = context.getSharedPreferences("aura_prefs", Context.MODE_PRIVATE)
            val historyKey = getChatHistoryKey()
            val historyJson = gson.toJson(_messages.value)

            sharedPrefs.edit()
                .putString(historyKey, historyJson)
                .apply()
        } catch (e: Exception) {
            // Silently fail if saving doesn't work
        }
    }

    private fun refreshUserCredits() {
        viewModelScope.launch {
            authRepository.getCurrentUser().collect { /* Update handled in repository */ }
        }
    }

    fun clearChatHistory() {
        _messages.value = emptyList()
        sessionId = generateSessionId()

        try {
            val sharedPrefs = context.getSharedPreferences("aura_prefs", Context.MODE_PRIVATE)
            val historyKey = getChatHistoryKey()
            sharedPrefs.edit().remove(historyKey).apply()
        } catch (e: Exception) {
            // Silently fail
        }
    }
}