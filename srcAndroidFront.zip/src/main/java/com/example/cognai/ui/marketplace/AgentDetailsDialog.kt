package com.example.cognai.ui.marketplace

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import com.example.cognai.R
import com.example.cognai.data.models.PrebuiltAgent
import com.example.cognai.databinding.DialogAgentDetailsBinding
import com.google.android.material.chip.Chip

class AgentDetailsDialog : DialogFragment() {

    private var _binding: DialogAgentDetailsBinding? = null
    private val binding get() = _binding!!

    private lateinit var agent: PrebuiltAgent
    private var onCloneClick: ((PrebuiltAgent) -> Unit)? = null

    companion object {
        private const val ARG_AGENT = "agent"

        fun newInstance(agent: PrebuiltAgent, onCloneClick: (PrebuiltAgent) -> Unit): AgentDetailsDialog {
            return AgentDetailsDialog().apply {
                arguments = Bundle().apply {
                    putParcelable(ARG_AGENT, agent)
                }
                this.onCloneClick = onCloneClick
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.Theme_AuraAI_Dialog_FullScreen)

        agent = arguments?.getParcelable(ARG_AGENT) ?: return
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DialogAgentDetailsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupUI()
        setupClickListeners()
    }

    private fun setupUI() {
        binding.apply {
            // Close button
            closeButton.setOnClickListener { dismiss() }

            // Agent basic info
            agentNameText.text = agent.name
            agentAvatarText.text = agent.name.firstOrNull()?.toString()?.uppercase() ?: "A"
            agentDescriptionText.text = agent.shortDescription

            // System type badge
            systemBadgeText.text = agent.systemType.uppercase()
            systemBadgeText.setBackgroundResource(
                if (agent.systemType == "ceaf") R.drawable.bg_ceaf_badge
                else R.drawable.bg_ncf_badge
            )

            // Archetype and maturity
            archetypeText.text = agent.archetype.replaceFirstChar { it.uppercase() }
            maturityText.text = agent.maturityLevel.replaceFirstChar { it.uppercase() }
            maturityText.setBackgroundResource(getMaturityBadgeResource(agent.maturityLevel))

            // Rating with stars
            val stars = "★".repeat(agent.rating.toInt()) + "☆".repeat(5 - agent.rating.toInt())
            ratingText.text = "$stars ${String.format("%.1f", agent.rating)}"

            // Statistics
            downloadsText.text = "${formatNumber(agent.downloadCount)} downloads"
            conversationsText.text = "${formatNumber(agent.totalInteractions)} conversations"

            // Capabilities chips
            setupCapabilities()

            // Sample memories
            setupSampleMemories()

            // System type description
            setupSystemDescription()
        }
    }

    private fun setupClickListeners() {
        binding.cloneButton.setOnClickListener {
            onCloneClick?.invoke(agent)
            dismiss()
        }

        binding.cancelButton.setOnClickListener {
            dismiss()
        }
    }

    private fun setupCapabilities() {
        binding.capabilitiesContainer.removeAllViews()

        val capabilities = listOf(
            "Memory System",
            if (agent.systemType == "ceaf") "Emergence" else "Narrative",
            "Contextual",
            "Multi-turn Conversations",
            "Personality Consistency"
        ) + if (agent.systemType == "ceaf") listOf("Breakthrough Learning", "Adaptive Growth") else emptyList()

        capabilities.forEach { capability ->
            val chip = Chip(requireContext()).apply {
                text = capability
                setChipBackgroundColorResource(R.color.aura_surface_variant)
                setTextColor(ContextCompat.getColor(context, R.color.aura_text_secondary))
                textSize = 12f
                isClickable = false
                chipCornerRadius = 16f
            }
            binding.capabilitiesContainer.addView(chip)
        }
    }

    private fun setupSampleMemories() {
        binding.sampleMemoriesContainer.removeAllViews()

        if (agent.sampleMemories.isNullOrEmpty()) {
            binding.sampleMemoriesSection.visibility = View.GONE
            return
        }

        agent.sampleMemories?.forEach { memory ->
            val memoryView = LayoutInflater.from(requireContext())
                .inflate(R.layout.item_sample_memory_detailed, binding.sampleMemoriesContainer, false)

            val typeText = memoryView.findViewById<android.widget.TextView>(R.id.memoryTypeText)
            val contentText = memoryView.findViewById<android.widget.TextView>(R.id.memoryContentText)

            typeText.text = memory.type
            contentText.text = "\"${memory.content}\""

            // Color code by memory type
            val typeColor = when (memory.type.lowercase()) {
                "explicit" -> R.color.aura_info
                "emotional" -> R.color.aura_warning
                "procedural" -> R.color.aura_success
                "episodic" -> R.color.aura_primary
                "semantic" -> R.color.aura_secondary
                else -> R.color.aura_text_secondary
            }
            typeText.setTextColor(ContextCompat.getColor(requireContext(), typeColor))

            binding.sampleMemoriesContainer.addView(memoryView)
        }

        binding.sampleMemoriesSection.visibility = View.VISIBLE
    }

    private fun setupSystemDescription() {
        val description = when (agent.systemType.lowercase()) {
            "ceaf" -> "CEAF (Contextual Emergence and Adaptive Framing) agents use advanced memory systems that allow for breakthrough learning and adaptive personality growth through challenging interactions."
            "ncf" -> "NCF (Narrative Context Framing) agents maintain consistent personalities with isolated memory systems, providing stable and reliable interactions."
            else -> "This agent uses a custom memory system designed for optimal conversational experiences."
        }

        binding.systemDescriptionText.text = description
    }

    private fun getMaturityBadgeResource(maturityLevel: String): Int {
        return when (maturityLevel.lowercase()) {
            "newborn" -> R.drawable.bg_maturity_newborn
            "learning" -> R.drawable.bg_maturity_learning
            "developing" -> R.drawable.bg_maturity_developing
            "mature" -> R.drawable.bg_maturity_mature
            "experienced" -> R.drawable.bg_maturity_experienced
            "master" -> R.drawable.bg_maturity_master
            else -> R.drawable.bg_maturity_newborn
        }
    }

    private fun formatNumber(number: Int): String {
        return when {
            number >= 1_000_000 -> String.format("%.1fM", number / 1_000_000.0)
            number >= 1_000 -> String.format("%.1fK", number / 1_000.0)
            else -> number.toString()
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState)
        dialog.window?.setWindowAnimations(R.style.DialogSlideAnimation)
        return dialog
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}