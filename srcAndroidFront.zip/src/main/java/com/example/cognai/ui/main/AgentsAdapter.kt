package com.example.cognai.ui.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.cognai.R
import com.example.cognai.data.models.Agent
import com.example.cognai.databinding.ItemAgentBinding
import java.text.SimpleDateFormat
import java.util.*

class AgentsAdapter(
    private val onAgentClick: (Agent) -> Unit,
    private val onEditClick: (Agent) -> Unit,
    private val onDeleteClick: (Agent) -> Unit
) : ListAdapter<Agent, AgentsAdapter.AgentViewHolder>(AgentDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AgentViewHolder {
        val binding = ItemAgentBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return AgentViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AgentViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class AgentViewHolder(
        private val binding: ItemAgentBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(agent: Agent) {
            binding.apply {
                // Set agent name and avatar
                agentNameText.text = agent.name
                agentAvatarText.text = agent.name.firstOrNull()?.toString()?.uppercase() ?: "A"

                // Set persona/description
                agentPersonaText.text = agent.persona

                // Set system type badge
                val systemType = agent.settings?.systemType ?: "ncf"
                systemBadge.text = systemType.uppercase()
                systemBadge.setBackgroundResource(
                    if (systemType == "ceaf") R.drawable.bg_ceaf_badge
                    else R.drawable.bg_ncf_badge
                )

                // Show cloned badge if applicable
                if (agent.settings?.clonedFrom != null) {
                    clonedBadge.visibility = android.view.View.VISIBLE
                } else {
                    clonedBadge.visibility = android.view.View.GONE
                }

                // Format creation date
                try {
                    val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
                    val outputFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                    val date = inputFormat.parse(agent.createdAt)
                    createdText.text = "Created ${outputFormat.format(date ?: Date())}"
                } catch (e: Exception) {
                    createdText.text = "Created recently"
                }

                // Set click listeners
                root.setOnClickListener { onAgentClick(agent) }
                editButton.setOnClickListener { onEditClick(agent) }
                deleteButton.setOnClickListener { onDeleteClick(agent) }

                // Set up capability tags
                setupCapabilityTags(systemType)
            }
        }

        private fun setupCapabilityTags(systemType: String) {
            binding.capabilityContainer.removeAllViews()

            val capabilities = listOf(
                "Memory System",
                if (systemType == "ceaf") "Emergence" else "Narrative",
                "Contextual"
            ) + if (systemType == "ceaf") listOf("Breakthrough Learning") else emptyList()

            capabilities.forEach { capability ->
                val chip = com.google.android.material.chip.Chip(binding.root.context).apply {
                    text = capability
                    setChipBackgroundColorResource(R.color.aura_surface_variant)
                    setTextColor(binding.root.context.getColor(R.color.aura_text_secondary))
                    textSize = 10f
                    isClickable = false
                }
                binding.capabilityContainer.addView(chip)
            }
        }
    }

    private class AgentDiffCallback : DiffUtil.ItemCallback<Agent>() {
        override fun areItemsTheSame(oldItem: Agent, newItem: Agent): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Agent, newItem: Agent): Boolean {
            return oldItem == newItem
        }
    }
}