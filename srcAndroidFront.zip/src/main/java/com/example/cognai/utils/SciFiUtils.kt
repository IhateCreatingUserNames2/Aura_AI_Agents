package com.example.cognai.utils

import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.core.content.ContextCompat
import com.example.cognai.R
import kotlin.math.sin

object SciFiUtils {

    /**
     * Aplica efeito de brilho holográfico em uma view
     */
    fun applyHolographicGlow(view: View, color: Int, duration: Long = 2000): ValueAnimator {
        return ValueAnimator.ofFloat(0.3f, 1f).apply {
            this.duration = duration
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()

            addUpdateListener { animator ->
                val alpha = animator.animatedValue as Float
                view.alpha = 0.7f + (alpha * 0.3f)
            }
            start()
        }
    }

    /**
     * Cria um background gradient sci-fi
     */
    fun createGradientBackground(
        context: Context,
        startColor: Int,
        endColor: Int,
        cornerRadius: Float = 16f
    ): GradientDrawable {
        return GradientDrawable().apply {
            colors = intArrayOf(startColor, endColor)
            gradientType = GradientDrawable.LINEAR_GRADIENT
            orientation = GradientDrawable.Orientation.TL_BR
            this.cornerRadius = cornerRadius

            // Adiciona borda sutil
            setStroke(2, ContextCompat.getColor(context, R.color.aura_primary_glow))
        }
    }

    /**
     * Anima transição de cores suave
     */
    fun animateColorTransition(
        view: View,
        fromColor: Int,
        toColor: Int,
        duration: Long = 500,
        onUpdate: (Int) -> Unit
    ): ValueAnimator {
        return ValueAnimator.ofObject(ArgbEvaluator(), fromColor, toColor).apply {
            this.duration = duration
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { animator ->
                val animatedColor = animator.animatedValue as Int
                onUpdate(animatedColor)
            }
            start()
        }
    }

    /**
     * Cria animação de pulse contínua
     */
    fun createPulseAnimation(
        view: View,
        scale: Float = 1.1f,
        duration: Long = 1000
    ): ObjectAnimator {
        return ObjectAnimator.ofFloat(view, "scaleX", 1f, scale, 1f).apply {
            this.duration = duration
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()

            // Anima também scaleY
            val scaleYAnimator = ObjectAnimator.ofFloat(view, "scaleY", 1f, scale, 1f).apply {
                this.duration = duration
                repeatCount = ValueAnimator.INFINITE
                interpolator = AccelerateDecelerateInterpolator()
            }

            start()
            scaleYAnimator.start()
        }
    }

    /**
     * Cria efeito de linha de escaneamento
     */
    fun createScanlineEffect(view: View, duration: Long = 3000): ValueAnimator {
        val overlay = View(view.context).apply {
            background = ContextCompat.getDrawable(context, R.drawable.bg_scanning_animation)
            alpha = 0f
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Adiciona overlay à view parent se possível
        (view.parent as? ViewGroup)?.addView(overlay)

        return ValueAnimator.ofFloat(0f, 1f).apply {
            this.duration = duration
            repeatCount = ValueAnimator.INFINITE

            addUpdateListener { animator ->
                val progress = animator.animatedValue as Float
                overlay.alpha = sin(progress * Math.PI).toFloat() * 0.5f
                overlay.translationY = progress * view.height
            }
            start()
        }
    }

    /**
     * Obtém a cor do sistema baseada no tipo
     */
    fun getSystemTypeColor(context: Context, systemType: String): Int {
        return when (systemType.lowercase()) {
            "ceaf" -> ContextCompat.getColor(context, R.color.aura_ceaf)
            "ncf" -> ContextCompat.getColor(context, R.color.aura_ncf)
            else -> ContextCompat.getColor(context, R.color.aura_primary)
        }
    }

    /**
     * Obtém a cor de brilho do sistema
     */
    fun getSystemTypeGlowColor(context: Context, systemType: String): Int {
        return when (systemType.lowercase()) {
            "ceaf" -> ContextCompat.getColor(context, R.color.aura_primary_glow)
            "ncf" -> ContextCompat.getColor(context, R.color.aura_success_glow)
            else -> ContextCompat.getColor(context, R.color.aura_secondary_glow)
        }
    }

    /**
     * Formata estatísticas do agente
     */
    fun formatAgentStats(
        totalMemories: Int,
        systemType: String,
        isOnline: Boolean
    ): String {
        val memoryText = when {
            totalMemories > 1000 -> "${totalMemories / 1000}K memories"
            totalMemories > 0 -> "$totalMemories memories"
            else -> "New agent"
        }

        val statusText = if (isOnline) "ONLINE" else "OFFLINE"

        return "$memoryText • ${systemType.uppercase()} • $statusText"
    }

    /**
     * Cria animação de entrada escalonada para múltiplas views
     */
    fun createStaggeredEntranceAnimation(
        views: List<View>,
        delayBetween: Long = 100,
        duration: Long = 400
    ) {
        views.forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationY = 50f
            view.scaleX = 0.8f
            view.scaleY = 0.8f

            Handler(Looper.getMainLooper()).postDelayed({
                view.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(duration)
                    .setInterpolator(OvershootInterpolator())
                    .start()
            }, index * delayBetween)
        }
    }

    /**
     * Aplica efeito hover sci-fi
     */
    fun applyHoverEffect(view: View, isHovering: Boolean, duration: Long = 200) {
        val targetElevation = if (isHovering) 16f else 8f
        val targetScale = if (isHovering) 1.02f else 1f
        val targetAlpha = if (isHovering) 1f else 0.9f

        view.animate()
            .scaleX(targetScale)
            .scaleY(targetScale)
            .alpha(targetAlpha)
            .translationZ(targetElevation)
            .setDuration(duration)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .start()
    }

    /**
     * Cria efeito de click com feedback visual
     */
    fun createClickFeedback(
        view: View,
        onComplete: (() -> Unit)? = null,
        showScanEffect: Boolean = true
    ) {
        // Animação de scale down/up
        view.animate()
            .scaleX(0.95f)
            .scaleY(0.95f)
            .setDuration(100)
            .withEndAction {
                view.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(100)
                    .withEndAction { onComplete?.invoke() }
                    .start()
            }
            .start()

        // Efeito de escaneamento se solicitado
        if (showScanEffect) {
            val overlay = View(view.context).apply {
                background = ContextCompat.getDrawable(context, R.drawable.bg_scanning_animation)
                alpha = 0f
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }

            (view as? ViewGroup)?.addView(overlay)

            overlay.animate()
                .alpha(1f)
                .setDuration(150)
                .withEndAction {
                    overlay.animate()
                        .alpha(0f)
                        .setDuration(150)
                        .withEndAction {
                            (view as? ViewGroup)?.removeView(overlay)
                        }
                        .start()
                }
                .start()
        }
    }

    /**
     * Aplica efeito de shimmer holográfico
     */
    fun createShimmerEffect(view: View, duration: Long = 2000): ValueAnimator {
        return ValueAnimator.ofFloat(0f, 1f).apply {
            this.duration = duration
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE

            addUpdateListener { animator ->
                val progress = animator.animatedValue as Float
                val shimmerAlpha = (sin(progress * Math.PI * 2) * 0.3f + 0.7f)
                view.alpha = shimmerAlpha.toFloat()
            }
            start()
        }
    }

    /**
     * Cria gradiente animado para backgrounds
     */
    fun createAnimatedGradient(
        context: Context,
        colors: IntArray,
        duration: Long = 3000
    ): ValueAnimator {
        return ValueAnimator.ofFloat(0f, 1f).apply {
            this.duration = duration
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE

            addUpdateListener { animator ->
                val progress = animator.animatedValue as Float
                // Implementação de gradiente animado personalizada
                // Pode ser expandida conforme necessidade
            }
        }
    }

    /**
     * Converte DP para PX
     */
    fun dpToPx(context: Context, dp: Float): Int {
        return (dp * context.resources.displayMetrics.density).toInt()
    }

    /**
     * Converte PX para DP
     */
    fun pxToDp(context: Context, px: Float): Int {
        return (px / context.resources.displayMetrics.density).toInt()
    }

    /**
     * Verifica se a animação deve ser executada (considera preferências de acessibilidade)
     */
    fun shouldAnimateUI(context: Context): Boolean {
        // Verifica configurações de acessibilidade
        val scale = android.provider.Settings.Global.getFloat(
            context.contentResolver,
            android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,
            1f
        )
        return scale > 0f
    }

    /**
     * Para todas as animações de uma view
     */
    fun stopAllAnimations(view: View) {
        view.animate().cancel()
        view.clearAnimation()
    }

    /**
     * Para todas as animações de uma ViewGroup recursivamente
     */
    fun stopAllAnimationsRecursive(viewGroup: ViewGroup) {
        stopAllAnimations(viewGroup)
        for (i in 0 until viewGroup.childCount) {
            val child = viewGroup.getChildAt(i)
            if (child is ViewGroup) {
                stopAllAnimationsRecursive(child)
            } else {
                stopAllAnimations(child)
            }
        }
    }

    /**
     * Classe para gerenciar múltiplas animações
     */
    class AnimationManager {
        private val animations = mutableListOf<ValueAnimator>()

        fun addAnimation(animator: ValueAnimator) {
            animations.add(animator)
        }

        fun startAll() {
            animations.forEach { it.start() }
        }

        fun stopAll() {
            animations.forEach {
                it.cancel()
            }
        }

        fun pauseAll() {
            animations.forEach {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
                    it.pause()
                }
            }
        }

        fun resumeAll() {
            animations.forEach {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
                    it.resume()
                }
            }
        }

        fun clear() {
            stopAll()
            animations.clear()
        }
    }
}