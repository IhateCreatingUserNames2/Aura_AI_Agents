package com.example.cognai.utils

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AppStateManager @Inject constructor() {

    private var isAuthenticationInProgress = false
    private var hasAuthenticationFailed = false

    fun setAuthenticationInProgress(inProgress: Boolean) {
        isAuthenticationInProgress = inProgress
        if (inProgress) {
            hasAuthenticationFailed = false
        }
    }

    fun isAuthenticationInProgress(): Boolean = isAuthenticationInProgress

    fun setAuthenticationFailed(failed: Boolean) {
        hasAuthenticationFailed = failed
        if (failed) {
            isAuthenticationInProgress = false
        }
    }

    fun hasAuthenticationFailed(): Boolean = hasAuthenticationFailed

    fun reset() {
        isAuthenticationInProgress = false
        hasAuthenticationFailed = false
    }
}