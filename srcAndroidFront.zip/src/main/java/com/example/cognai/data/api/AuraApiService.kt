package com.example.cognai.data.api

import com.example.cognai.data.models.*
import retrofit2.Response
import retrofit2.http.*

interface AuraApiService {

    // Authentication
    @POST("auth/login")
    suspend fun login(@Body request: LoginRequest): Response<AuthResponse>

    @POST("auth/register")
    suspend fun register(@Body request: RegisterRequest): Response<AuthResponse>

    @GET("auth/me")
    suspend fun getCurrentUser(): Response<AuthResponse>

    // Agents
    @GET("agents/list")
    suspend fun getAgents(): Response<List<Agent>>

    @POST("agents/create")
    suspend fun createAgent(@Body request: CreateAgentRequest): Response<Agent>

    @POST("agents/ceaf/create")
    suspend fun createCeafAgent(@Body request: CreateAgentRequest): Response<Agent>

    @GET("agents/{agentId}/profile")
    suspend fun getAgentProfile(@Path("agentId") agentId: String): Response<Agent>

    @PUT("agents/{agentId}/profile")
    suspend fun updateAgentProfile(
        @Path("agentId") agentId: String,
        @Body request: UpdateAgentRequest
    ): Response<Agent>

    @DELETE("agents/{agentId}")
    suspend fun deleteAgent(@Path("agentId") agentId: String): Response<Unit>

    // Prebuilt Agents & Marketplace
    @GET("prebuilt-agents")
    suspend fun getPrebuiltAgents(): Response<List<PrebuiltAgent>>

    @GET("agents/public")
    suspend fun getPublicAgents(): Response<List<PrebuiltAgent>>

    @POST("agents/clone")
    suspend fun cloneAgent(@Body request: CloneAgentRequest): Response<Agent>

    // Chat
    @POST("agents/{agentId}/chat")
    suspend fun sendMessage(
        @Path("agentId") agentId: String,
        @Body request: ChatRequest
    ): Response<ChatResponse>

    // Memory Management
    @GET("agents/{agentId}/memories")
    suspend fun getMemories(
        @Path("agentId") agentId: String,
        @Query("limit") limit: Int = 50
    ): Response<MemoryStats>

    @GET("agents/{agentId}/memories/analytics")
    suspend fun getMemoryAnalytics(@Path("agentId") agentId: String): Response<MemoryAnalytics>

    // Models
    @GET("models/openrouter")
    suspend fun getAvailableModels(): Response<Map<String, List<String>>>
}