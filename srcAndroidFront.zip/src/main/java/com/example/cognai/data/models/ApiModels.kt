package com.example.cognai.data.models

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

// Auth Models
data class LoginRequest(
    val username: String,
    val password: String
)

data class RegisterRequest(
    val username: String,
    val password: String,
    val email: String
)

data class AuthResponse(
    @SerializedName("access_token") val accessToken: String,
    val username: String,
    val credits: Int,
    val email: String? = null
)

// Agent Models
@Parcelize
data class Agent(
    @SerializedName("agent_id") val id: String,
    val name: String,
    val persona: String,
    @SerializedName("detailed_persona") val detailedPersona: String? = null,
    @SerializedName("created_at") val createdAt: String,
    val settings: AgentSettings? = null
) : Parcelable

@Parcelize
data class AgentSettings(
    @SerializedName("system_type") val systemType: String? = null,
    val archetype: String? = null,
    @SerializedName("cloned_from") val clonedFrom: String? = null
) : Parcelable

data class CreateAgentRequest(
    val name: String,
    val persona: String,
    @SerializedName("detailed_persona") val detailedPersona: String,
    @SerializedName("system_type") val systemType: String = "ncf",
    val model: String = "openai/gpt-3.5-turbo"
)

data class UpdateAgentRequest(
    val name: String,
    val persona: String,
    @SerializedName("detailed_persona") val detailedPersona: String
)

// Chat Models
data class ChatRequest(
    val message: String,
    @SerializedName("session_id") val sessionId: String
)

data class ChatResponse(
    val response: String,
    @SerializedName("session_id") val sessionId: String? = null
)

@Parcelize
data class ChatMessage(
    val role: String, // "user" or "assistant"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val sessionId: String? = null
) : Parcelable

// Prebuilt Agent Models
@Parcelize
data class PrebuiltAgent(
    val id: String,
    val name: String,
    @SerializedName("short_description") val shortDescription: String,
    @SerializedName("system_type") val systemType: String,
    val archetype: String,
    @SerializedName("maturity_level") val maturityLevel: String,
    val rating: Float,
    @SerializedName("download_count") val downloadCount: Int,
    @SerializedName("total_interactions") val totalInteractions: Int,
    @SerializedName("sample_memories") val sampleMemories: List<SampleMemory>? = null
) : Parcelable

@Parcelize
data class SampleMemory(
    val type: String,
    val content: String
) : Parcelable

data class CloneAgentRequest(
    @SerializedName("source_agent_id") val sourceAgentId: String,
    @SerializedName("custom_name") val customName: String,
    @SerializedName("clone_memories") val cloneMemories: Boolean = true
)

// Memory Models
data class Memory(
    val id: String? = null,
    val type: String,
    val content: String,
    val importance: Float? = null,
    val emotion: String? = null,
    @SerializedName("created_at") val createdAt: String? = null
)

data class MemoryStats(
    @SerializedName("total_memories") val totalMemories: Int,
    @SerializedName("memory_types") val memoryTypes: List<String>
)

data class MemoryAnalytics(
    @SerializedName("total_memories") val totalMemories: Int,
    @SerializedName("memory_types") val memoryTypes: Map<String, Int>,
    @SerializedName("emotion_distribution") val emotionDistribution: Map<String, Int>,
    @SerializedName("recent_activity") val recentActivity: Map<String, Int>,
    @SerializedName("top_memory_sources") val topMemorySources: Map<String, Int>
)

// API Response Models
data class ApiResponse<T>(
    val success: Boolean = true,
    val data: T? = null,
    val message: String? = null,
    val error: String? = null
)

data class ErrorResponse(
    val detail: String
)

// Model lists for creation
data class ModelCategory(
    val category: String,
    val models: List<String>
)