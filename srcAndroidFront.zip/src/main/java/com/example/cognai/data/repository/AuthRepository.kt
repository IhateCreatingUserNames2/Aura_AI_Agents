package com.example.cognai.data.repository

import com.example.cognai.data.api.AuraApiService
import com.example.cognai.data.local.TokenManager
import com.example.cognai.data.models.AuthResponse
import com.example.cognai.data.models.LoginRequest
import com.example.cognai.data.models.RegisterRequest
import com.example.cognai.utils.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthRepository @Inject constructor(
    private val apiService: AuraApiService,
    private val tokenManager: TokenManager
) {

    suspend fun login(username: String, password: String): Flow<Resource<AuthResponse>> = flow {
        try {
            emit(Resource.Loading())
            val response = apiService.login(LoginRequest(username, password))

            if (response.isSuccessful) {
                val authResponse = response.body()
                if (authResponse != null) {
                    // Save token and user info
                    tokenManager.saveToken(authResponse.accessToken)
                    tokenManager.saveUserInfo(
                        username = authResponse.username,
                        credits = authResponse.credits,
                        email = authResponse.email
                    )
                    emit(Resource.Success(authResponse))
                } else {
                    emit(Resource.Error("Login failed - empty response"))
                }
            } else {
                val errorBody = response.errorBody()?.string()
                val errorMessage = when {
                    response.code() == 401 -> "Invalid username or password"
                    response.code() == 403 -> "Account access denied"
                    response.code() == 429 -> "Too many login attempts. Please try again later"
                    errorBody?.contains("error") == true -> {
                        try {
                            // Try to parse error message from response
                            errorBody.substringAfter("\"error\":\"").substringBefore("\"")
                        } catch (e: Exception) {
                            "Login failed: ${response.message()}"
                        }
                    }
                    else -> "Login failed: ${response.message()}"
                }
                emit(Resource.Error(errorMessage))
            }
        } catch (e: Exception) {
            val errorMessage = when {
                e.message?.contains("timeout") == true -> "Connection timeout. Please check your internet connection"
                e.message?.contains("Unable to resolve host") == true -> "Cannot connect to server. Please check your internet connection"
                else -> "Network error: ${e.message}"
            }
            emit(Resource.Error(errorMessage))
        }
    }

    suspend fun register(username: String, password: String, email: String): Flow<Resource<AuthResponse>> = flow {
        try {
            emit(Resource.Loading())
            val response = apiService.register(RegisterRequest(username, password, email))

            if (response.isSuccessful) {
                val authResponse = response.body()
                if (authResponse != null) {
                    // Save token and user info
                    tokenManager.saveToken(authResponse.accessToken)
                    tokenManager.saveUserInfo(
                        username = authResponse.username,
                        credits = authResponse.credits,
                        email = authResponse.email
                    )
                    emit(Resource.Success(authResponse))
                } else {
                    emit(Resource.Error("Registration failed - empty response"))
                }
            } else {
                val errorBody = response.errorBody()?.string()
                val errorMessage = when {
                    response.code() == 409 -> "Username or email already exists"
                    response.code() == 400 -> "Invalid registration data"
                    response.code() == 429 -> "Too many registration attempts. Please try again later"
                    errorBody?.contains("error") == true -> {
                        try {
                            errorBody.substringAfter("\"error\":\"").substringBefore("\"")
                        } catch (e: Exception) {
                            "Registration failed: ${response.message()}"
                        }
                    }
                    else -> "Registration failed: ${response.message()}"
                }
                emit(Resource.Error(errorMessage))
            }
        } catch (e: Exception) {
            val errorMessage = when {
                e.message?.contains("timeout") == true -> "Connection timeout. Please check your internet connection"
                e.message?.contains("Unable to resolve host") == true -> "Cannot connect to server. Please check your internet connection"
                else -> "Network error: ${e.message}"
            }
            emit(Resource.Error(errorMessage))
        }
    }

    suspend fun getCurrentUser(): Flow<Resource<AuthResponse>> = flow {
        try {
            emit(Resource.Loading())

            // Check if we have a valid token first
            if (!tokenManager.isLoggedIn()) {
                emit(Resource.Error("Not authenticated"))
                return@flow
            }

            val response = apiService.getCurrentUser()

            if (response.isSuccessful) {
                val userResponse = response.body()
                if (userResponse != null) {
                    // Update stored user info and refresh token timestamp
                    tokenManager.saveUserInfo(
                        username = userResponse.username,
                        credits = userResponse.credits,
                        email = userResponse.email
                    )
                    tokenManager.refreshTokenTimestamp()
                    emit(Resource.Success(userResponse))
                } else {
                    emit(Resource.Error("Failed to get user info - empty response"))
                }
            } else {
                val errorBody = response.errorBody()?.string()
                val errorMessage = when {
                    response.code() == 401 || response.code() == 403 -> {
                        // Token is invalid, clear it
                        tokenManager.clearAll()
                        "Not authenticated"
                    }
                    errorBody?.contains("error") == true -> {
                        try {
                            errorBody.substringAfter("\"error\":\"").substringBefore("\"")
                        } catch (e: Exception) {
                            "Failed to get user info: ${response.message()}"
                        }
                    }
                    else -> "Failed to get user info: ${response.message()}"
                }
                emit(Resource.Error(errorMessage))
            }
        } catch (e: Exception) {
            val errorMessage = when {
                e.message?.contains("timeout") == true -> "Connection timeout. Please check your internet connection"
                e.message?.contains("Unable to resolve host") == true -> "Cannot connect to server. Please check your internet connection"
                else -> "Network error: ${e.message}"
            }
            emit(Resource.Error(errorMessage))
        }
    }

    fun logout() {
        tokenManager.clearAll()
    }

    fun isLoggedIn(): Boolean {
        return tokenManager.isLoggedIn()
    }

    fun getStoredUsername(): String? {
        return tokenManager.getUsername()
    }

    fun getStoredCredits(): Int {
        return tokenManager.getCredits()
    }
}