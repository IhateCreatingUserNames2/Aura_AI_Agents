package com.example.cognai.data.repository

import com.example.cognai.data.api.AuraApiService
import com.example.cognai.data.models.*
import com.example.cognai.utils.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AgentRepository @Inject constructor(
    private val apiService: AuraApiService
) {

    suspend fun getAgents(): Flow<Resource<List<Agent>>> = flow {
        try {
            emit(Resource.Loading())
            val response = apiService.getAgents()

            if (response.isSuccessful) {
                val agents = response.body() ?: emptyList()
                emit(Resource.Success(agents))
            } else {
                emit(Resource.Error("Failed to load agents"))
            }
        } catch (e: Exception) {
            emit(Resource.Error("Network error: ${e.message}"))
        }
    }

    suspend fun createAgent(
        name: String,
        persona: String,
        detailedPersona: String,
        systemType: String = "ncf",
        model: String = "openai/gpt-3.5-turbo"
    ): Flow<Resource<Agent>> = flow {
        try {
            emit(Resource.Loading())
            val request = CreateAgentRequest(name, persona, detailedPersona, systemType, model)

            val response = if (systemType == "ceaf") {
                apiService.createCeafAgent(request)
            } else {
                apiService.createAgent(request)
            }

            if (response.isSuccessful) {
                val agent = response.body()
                if (agent != null) {
                    emit(Resource.Success(agent))
                } else {
                    emit(Resource.Error("Failed to create agent"))
                }
            } else {
                emit(Resource.Error("Failed to create agent: ${response.message()}"))
            }
        } catch (e: Exception) {
            emit(Resource.Error("Network error: ${e.message}"))
        }
    }

    suspend fun updateAgentProfile(
        agentId: String,
        name: String,
        persona: String,
        detailedPersona: String
    ): Flow<Resource<Agent>> = flow {
        try {
            emit(Resource.Loading())
            val request = UpdateAgentRequest(name, persona, detailedPersona)
            val response = apiService.updateAgentProfile(agentId, request)

            if (response.isSuccessful) {
                val agent = response.body()
                if (agent != null) {
                    emit(Resource.Success(agent))
                } else {
                    emit(Resource.Error("Failed to update agent"))
                }
            } else {
                emit(Resource.Error("Failed to update agent: ${response.message()}"))
            }
        } catch (e: Exception) {
            emit(Resource.Error("Network error: ${e.message}"))
        }
    }

    suspend fun deleteAgent(agentId: String): Flow<Resource<Unit>> = flow {
        try {
            emit(Resource.Loading())
            val response = apiService.deleteAgent(agentId)

            if (response.isSuccessful) {
                emit(Resource.Success(Unit))
            } else {
                emit(Resource.Error("Failed to delete agent"))
            }
        } catch (e: Exception) {
            emit(Resource.Error("Network error: ${e.message}"))
        }
    }

    suspend fun getPrebuiltAgents(): Flow<Resource<List<PrebuiltAgent>>> = flow {
        try {
            emit(Resource.Loading())
            val response = apiService.getPrebuiltAgents()

            if (response.isSuccessful) {
                val agents = response.body() ?: emptyList()
                emit(Resource.Success(agents))
            } else {
                emit(Resource.Error("Failed to load prebuilt agents"))
            }
        } catch (e: Exception) {
            emit(Resource.Error("Network error: ${e.message}"))
        }
    }

    suspend fun getPublicAgents(): Flow<Resource<List<PrebuiltAgent>>> = flow {
        try {
            emit(Resource.Loading())
            val response = apiService.getPublicAgents()

            if (response.isSuccessful) {
                val agents = response.body() ?: emptyList()
                emit(Resource.Success(agents))
            } else {
                emit(Resource.Error("Failed to load public agents"))
            }
        } catch (e: Exception) {
            emit(Resource.Error("Network error: ${e.message}"))
        }
    }

    suspend fun cloneAgent(
        sourceAgentId: String,
        customName: String,
        cloneMemories: Boolean = true
    ): Flow<Resource<Agent>> = flow {
        try {
            emit(Resource.Loading())
            val request = CloneAgentRequest(sourceAgentId, customName, cloneMemories)
            val response = apiService.cloneAgent(request)

            if (response.isSuccessful) {
                val agent = response.body()
                if (agent != null) {
                    emit(Resource.Success(agent))
                } else {
                    emit(Resource.Error("Failed to clone agent"))
                }
            } else {
                emit(Resource.Error("Failed to clone agent: ${response.message()}"))
            }
        } catch (e: Exception) {
            emit(Resource.Error("Network error: ${e.message}"))
        }
    }

    suspend fun getAvailableModels(): Flow<Resource<Map<String, List<String>>>> = flow {
        try {
            emit(Resource.Loading())
            val response = apiService.getAvailableModels()

            if (response.isSuccessful) {
                val models = response.body() ?: emptyMap()
                emit(Resource.Success(models))
            } else {
                emit(Resource.Error("Failed to load models"))
            }
        } catch (e: Exception) {
            emit(Resource.Error("Network error: ${e.message}"))
        }
    }
}