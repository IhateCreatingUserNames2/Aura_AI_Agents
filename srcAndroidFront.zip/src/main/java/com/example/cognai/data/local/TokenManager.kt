package com.example.cognai.data.local

import android.content.Context
import android.content.SharedPreferences
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TokenManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        private const val PREF_NAME = "aura_prefs"
        private const val KEY_AUTH_TOKEN = "auth_token"
        private const val KEY_USERNAME = "username"
        private const val KEY_CREDITS = "credits"
        private const val KEY_EMAIL = "email"
        private const val KEY_TOKEN_TIMESTAMP = "token_timestamp"
    }

    private val sharedPreferences: SharedPreferences by lazy {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    fun saveToken(token: String) {
        sharedPreferences.edit()
            .putString(KEY_AUTH_TOKEN, token)
            .putLong(KEY_TOKEN_TIMESTAMP, System.currentTimeMillis())
            .apply()
    }

    fun getToken(): String? {
        val token = sharedPreferences.getString(KEY_AUTH_TOKEN, null)

        // Check if token is expired (24 hours)
        if (token != null) {
            val tokenTimestamp = sharedPreferences.getLong(KEY_TOKEN_TIMESTAMP, 0)
            val currentTime = System.currentTimeMillis()
            val tokenAge = currentTime - tokenTimestamp

            // If token is older than 24 hours, consider it expired
            if (tokenAge > 24 * 60 * 60 * 1000) {
                clearAll()
                return null
            }
        }

        return token
    }

    fun saveUserInfo(username: String, credits: Int, email: String? = null) {
        sharedPreferences.edit()
            .putString(KEY_USERNAME, username)
            .putInt(KEY_CREDITS, credits)
            .putString(KEY_EMAIL, email)
            .apply()
    }

    fun getUsername(): String? {
        return sharedPreferences.getString(KEY_USERNAME, null)
    }

    fun getCredits(): Int {
        return sharedPreferences.getInt(KEY_CREDITS, 0)
    }

    fun getEmail(): String? {
        return sharedPreferences.getString(KEY_EMAIL, null)
    }

    fun updateCredits(credits: Int) {
        sharedPreferences.edit()
            .putInt(KEY_CREDITS, credits)
            .apply()
    }

    fun clearAll() {
        sharedPreferences.edit().clear().apply()
    }

    fun isLoggedIn(): Boolean {
        val token = getToken() // This will return null if expired
        return !token.isNullOrEmpty()
    }

    fun refreshTokenTimestamp() {
        if (getToken() != null) {
            sharedPreferences.edit()
                .putLong(KEY_TOKEN_TIMESTAMP, System.currentTimeMillis())
                .apply()
        }
    }
}