package com.example.cognai.data.repository

import com.example.cognai.data.api.AuraApiService
import com.example.cognai.data.models.ChatMessage
import com.example.cognai.data.models.ChatRequest
import com.example.cognai.data.models.ChatResponse
import com.example.cognai.utils.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepository @Inject constructor(
    private val apiService: AuraApiService
) {

    suspend fun sendMessage(
        agentId: String,
        message: String,
        sessionId: String
    ): Flow<Resource<ChatResponse>> = flow {
        try {
            emit(Resource.Loading())
            val request = ChatRequest(message, sessionId)
            val response = apiService.sendMessage(agentId, request)

            if (response.isSuccessful) {
                val chatResponse = response.body()
                if (chatResponse != null) {
                    emit(Resource.Success(chatResponse))
                } else {
                    emit(Resource.Error("Empty response from server"))
                }
            } else {
                val errorBody = response.errorBody()?.string()
                val errorMessage = when {
                    errorBody?.contains("out of credits") == true ->
                        "You're out of credits. Please purchase more to continue chatting."
                    response.code() == 429 ->
                        "Too many requests. Please wait a moment before sending another message."
                    response.code() == 401 ->
                        "Authentication failed. Please login again."
                    else ->
                        "Failed to send message: ${response.message()}"
                }
                emit(Resource.Error(errorMessage))
            }
        } catch (e: Exception) {
            val errorMessage = when {
                e.message?.contains("timeout") == true ->
                    "Request timed out. Please check your connection and try again."
                e.message?.contains("network") == true ->
                    "Network error. Please check your internet connection."
                else ->
                    "An unexpected error occurred: ${e.message}"
            }
            emit(Resource.Error(errorMessage))
        }
    }
}